<?php

$con=mysqli_connect("localhost", "root", "") or die(mysqli_error());
$drop = "DROP DATABASE IF EXISTS gravam";
 $dro = mysqli_query ($con,$drop);
if($dro){
$create = "CREATE DATABASE IF NOT EXISTS gravam";
 $cre = mysqli_query ($con,$create);
 if($cre){
	
 
 }
 else{

 
 }
 }
 else{
 

 
 }

?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="app/media/images/ico.png">

    <title>Gravam doc app</title>
    <link href="app/media/css/bootstrap.min.css" rel="stylesheet">
    <link href="app/media/css/style.css" rel="stylesheet">
	<link rel="stylesheet" href="app/media/css/font-awesome.min.css" />

  </head>

  <body>

<!-- Header Starts -->
<div class="navbar-wrapper">

        <div class="navbar-inverse" role="navigation">
          <div class="container">
            <div class="navbar-header">
             <img class="logo" src="app/media/images/logo.png">

              <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target=".navbar-collapse">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
              </button>

            </div>


            <!-- Nav Starts -->
            <div class="navbar-collapse  collapse">
              <ul class="nav navbar-nav navbar-right">
					
              </ul>
            </div>
            <!-- #Nav Ends -->

          </div>
        </div>

    </div>
	<!-- #Header ends-->
	
    <div class="container">
		  <div class="row">
				<div class="col-md-2">
				</div>

				<div class="col-md-8">
					<div class="Cbox">
								<div class="row">
								<form  id="signup" class="fms" action="" method="post">
								<center><h3>Set-up</h3></center>
									<div class="col-md-6">
									
													<div class="form-group">
														<label class="mylabel">First name</label>
														<input type="text" name="first_name"class="form-control" placeholder="first name">
													</div>
											  
													<div class="form-group">
													<label class="mylabel">Last name </label>
														<input type="text" name="last_name" class="form-control" placeholder="last name">
													</div>
													
													<div class="form-group">
														<label class="mylabel">username </label>
														<input type="text" name="username" class="form-control" placeholder="Username">
													</div>
													
									
									</div>
					
										
									<div class="col-md-6">
											
						
													<div class="form-group">
														<label class="mylabel">Email </label>
														<input type="text" name="email"class="form-control" placeholder="email">
													</div>
											  
													<div class="form-group">
														<label class="mylabel">Password </label>
														<input type="password" name="password" class="form-control" placeholder="password">
													</div>
													<div class="info"></div>
													<center>	<button type="submit" class="btn btn-info">Set-up</button></center>
													
											
											
									</div>		
											
											
							</form>
								</div>	
								
					</div>
				</div>
						
				<div class="col-md-2">
				</div>					
					
		  </div>
    </div>
<br/><br/><br/><br/><br/><br/><br/>

<footer>

		<p>
		<div class="span5">
               <p><?php echo $date= date('Y');?> <a target="_blank" href="" title="gravam">Gravam</a>. All Rights Reserved.</p>
            </div>
			
		</p>

	</footer>
    <!-- Placed at the end of the document so the pages load faster -->
	<!-- start: JavaScript-->

	<script src="app/media/js/jquery.js"></script>
		<script src="app/media/js/bootstrap.min.js"></script>
		<!--table--->
		 <script src="app/media/js/jquery-1.7.2.min.js"></script>			
		 <script type="text/javascript" charset="utf-8" language="javascript" src="app/media/js/jquery.dataTables.js"></script>
		<script type="text/javascript" charset="utf-8" language="javascript" src="app/media/js/DT_bootstrap.js"></script>
				<script type="text/javascript">
$(document).ready(function (e) {
	$("#signup").on('submit',(function(e) {
		e.preventDefault();
		$.ajax({
        	url: "app/controller/setup.php",
			type: "POST",
			data:  new FormData(this),
			contentType: false,
    	    cache: false,
			processData:false,
				beforeSend: function() 
			{
				$(".info").html('<center><img class="gifi" src="app/media/images/loader.gif" alt="Loading...." align="absmiddle" title="Loading...."/></center>');
			},
			success: function(data)
		    {
			$(".info").fadeIn(5000).html(data);
	
		    },
		  	error: function() 
	    	{
	    	} 	        
	   });
	}));
});
</script>
	<!-- end: JavaScript-->

  </body>
</html>
