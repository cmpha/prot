<?php

include('class/main_class.php');
$dbtask=new SYSTEM_CLASS();
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="">

    <title>Medical council of Malawi</title>
    <link href="media/css/bootstrap.min.css" rel="stylesheet">
    <link href="media/css/style.css" rel="stylesheet">
	<link rel="stylesheet" href="media/css/font-awesome.min.css" />

  </head>

  <body>

<!-- Header Starts -->
<div class="navbar-wrapper">

        <div class="navbar-inverse" role="navigation">
          <div class="container">
            <div class="navbar-header">
                       <b class="logo"> <img class="logo" src="media/images/logo1.png">Medical Council of Malawi</b>

              <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target=".navbar-collapse">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
              </button>

            </div>


            <!-- Nav Starts -->
            <div class="navbar-collapse  collapse">
              <ul class="nav navbar-nav navbar-right">
					<li><a href="index.php">Login</a></li>
					<li  class="active"><a href="signup.php">Signup</a></li>
              </ul>
            </div>
            <!-- #Nav Ends -->

          </div>
        </div>

    </div>
	<!-- #Header ends-->
	
    <div class="container">
		  <div class="row">
		 
				<div class="col-md-6">
				
				 <center><h3>Join us!</h3>
				 <p> Welcome to our plartform and start sharing events start sharing events start sharing events</p></center>
				<div class="row">
				
<div class="about-grids">
							<div class="about-bottom-grids">

								<div class="col-sm-6 about-right"> 
									<div class="about-left-grids">
										<div class="col-md-2 about-left-img">
											<i class="fa fa-users"></i>
										</div>
										<div class="col-md-10 about-left-info">
											<h4>Join our plartform</h4>
											<p>Create, view and manage events and the Importance e .</p>
										</div>
										<div class="clearfix"> </div>
									</div>
								</div>
								
								<div class="col-sm-6 about-left">
									<div class="about-left-grids">
										<div class="col-md-2 about-left-img">
											<i class="fa fa-pencil-square-o"></i>
										</div>
										<div class="col-md-10 about-left-info">
											<h4>Events update</h4>
											<p>Dont miss events, join now and start sharing your events.</p>
										</div>
										<div class="clearfix"> </div>
									</div>
								</div>
								


								
								<div class="clearfix"> </div>
							</div>
							<div class="about-bottom-grids">
								
								<div class="col-sm-6 about-right">
									<div class="about-left-grids">
										<div class="col-md-2 about-left-img">
											<i class="fa fa-pencil-square-o"></i>
										</div>
										<div class="col-md-10 about-left-info">
											<h4>Events update</h4>
											<p>Dont miss events, join now and start sharing your events.</p>
										</div>
										<div class="clearfix"> </div>
									</div>
								</div>
								
								
								<div class="col-sm-6 about-right">
									<div class="about-left-grids">
										<div class="col-md-2 about-left-img">
											<i class="fa fa-pencil-square-o"></i>
										</div>
										<div class="col-md-10 about-left-info">
											<h4>Events update</h4>
											<p>Dont miss events, join now and start sharing your events.</p>
										</div>
										<div class="clearfix"> </div>
									</div>
								</div>
								
								
								
								<div class="clearfix"> </div>
							</div>

						</div>
				
				</div>
				
				
				</div>

				<div class="col-md-6">
					<div class="Cbox">
								<div class="row">
								<form  id="signup" class="fms" action="" method="post">
								<center><h3>Sign-up</h3></center>
									<div class="col-md-6">
									
													<div class="form-group">
														<label class="mylabel">First name</label>
														<input type="text" name="first_name"class="form-control" placeholder="first name">
													</div>
											  
													<div class="form-group">
													<label class="mylabel">Last name </label>
														<input type="text" name="last_name" class="form-control" placeholder="last name">
													</div>
													
													<div class="form-group">
														<label class="mylabel">username </label>
														<input type="text" name="username" class="form-control" placeholder="Username">

													</div>
											<div class="form-group">
													  <label class="mylabel"> choose user group</label>
													  <div class="controls">
														<select class="form-control" name="us_id">
															
																	<?php	 
																  $table="user_groups";
																	$db_users=$dbtask->getStuff($table);
																	while($row=$db_users->fetch(PDO::FETCH_ASSOC))
																	{
																		$us_id=$row['us_id'];
																		$us_name=$row['us_name'];
																		
																	?>																
														<option value="<?php echo $us_id;?>"><?php echo $us_name;?></option>
														<?php
														}													
														?>
														</select>
													  </div>
													</div>
										<input type="hidden" name="org_duty" value="none">
													
									
									</div>
					
										
									<div class="col-md-6">
													<div class="form-group">
													  <label class="mylabel"> choose Organisation</label>
													  <div class="controls">
														<select class="form-control" name="org_id">
														
																	<?php	 
																  $table="organisations";
																	$db_users=$dbtask->getStuff($table);
																	while($row=$db_users->fetch(PDO::FETCH_ASSOC))
																	{
																		$org_id=$row['org_id'];
																		$org_name=$row['org_name'];
																		
																	?>																
														<option value="<?php echo $org_id;?>"><?php echo $org_name;?></option>
														<?php
														}													
														?>
														</select>
													  </div>
													</div>											
						
													<div class="form-group">
														<label class="mylabel">Email </label>
														<input type="text" name="email"class="form-control" placeholder="username">
													</div>
											  
													<div class="form-group">
														<label class="mylabel">Password </label>
														<input type="password" name="password" class="form-control" placeholder="password">
													</div>
													<div class="info"></div>
													<center>	<button type="submit" class="btn btn-info">Sign-up</button></center>
													
											
											
									</div>		
											
											
							</form>
								</div>	
<center><p class="topspace"> Have an account with us? <a href="index.php">Login</a></p></center>								
					</div>
				</div>
						
								
					
		  </div>
    </div>

<section id="bottom" class="main">
    <!--Container-->
    <div class="container">

       
        <div class="row-fluid">

           
            <div class="col-md-3">
                <h4>medical Council of Malawi</h4>
                     <ul class="arrow">
                        <li><a href="">About Us</a></li>
                        <li><a href="#">Terms of Use</a></li>
                        <li><a href="#">Copyright</a></li>
                        <li><a href="#">News</a></li>

                    </ul>              
            </div>
          

           
            <div id="" class="col-md-3">

            </div>
       
            <div id="" class="col-md-3">
             
                <div>

                </div>
            </div>
        

            <div class="col-md-3">
            
            

        </div>

    </div>
   
</div>


</section>
<footer>

		<p>
		<div class="span5">
               <p> © 2017 <a target="_blank" href="" title="Medical council of Malawi">Medical council of Malawi</a>. All Rights Reserved.</p>
            </div>
			
		</p>

	</footer>
    <!-- Placed at the end of the document so the pages load faster -->
	<!-- start: JavaScript-->

	<script src="media/js/jquery.js"></script>
		<script src="media/js/bootstrap.min.js"></script>
		<!--table--->
		 <script src="media/js/jquery-1.7.2.min.js"></script>			
		 <script type="text/javascript" charset="utf-8" language="javascript" src="media/js/jquery.dataTables.js"></script>
		<script type="text/javascript" charset="utf-8" language="javascript" src="media/js/DT_bootstrap.js"></script>
				<script type="text/javascript">
$(document).ready(function (e) {
	$("#signup").on('submit',(function(e) {
		e.preventDefault();
		$.ajax({
        	url: "controller/signup.php",
			type: "POST",
			data:  new FormData(this),
			contentType: false,
    	    cache: false,
			processData:false,
				beforeSend: function() 
			{
				$(".info").html('<center><img class="gifi" src="media/images/loader.gif" alt="Loading...." align="absmiddle" title="Loading...."/></center>');
			},
			success: function(data)
		    {
			$(".info").fadeIn(5000).html(data);
	
		    },
		  	error: function() 
	    	{
	    	} 	        
	   });
	}));
});
</script>
	<!-- end: JavaScript-->

  </body>
</html>
