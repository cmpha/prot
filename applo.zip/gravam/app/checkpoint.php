<?php

include('class/main_class.php');
$dbtask=new SYSTEM_CLASS();
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="">

    <title>Medical council of Malawi</title>
    <link href="media/css/bootstrap.min.css" rel="stylesheet">
    <link href="media/css/style.css" rel="stylesheet">
	<link rel="stylesheet" href="media/css/font-awesome.min.css" />

  </head>

  <body>

<!-- Header Starts -->
<div class="navbar-wrapper">

        <div class="navbar-inverse" role="navigation">
          <div class="container">
            <div class="navbar-header">
                         <b class="logo"> <img class="logo" src="media/images/logo1.png">Medical Council of Malawi</b>

              <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target=".navbar-collapse">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
              </button>

            </div>


            <!-- Nav Starts -->
            <div class="navbar-collapse  collapse">
              <ul class="nav navbar-nav navbar-right">
					<li><a href="index.php">Login</a></li>
					<li  class="active"><a href="signup.php">Signup</a></li>
              </ul>
            </div>
            <!-- #Nav Ends -->

          </div>
        </div>

    </div>
	<!-- #Header ends-->
	<br/><br/>
    <div class="container">
		  <div class="row">
		 
				<div class="col-md-2">
				</div>

				<div class="col-md-8">
					<div class="Cbox">
								<div class="row">
										<div class="col-md-2">
										</div>
										<div class="col-md-8">
				
												<form  id="recover" class="fms" action="" method="post">
												<center><h3>Password recovery</h3>
												<p>Use the email registered with us and we will send the reset link tou your email</p>
												</center>

																	<div class="form-group">
																		<label class="mylabel">Email </label>
																		<input type="text" name="email"class="form-control" placeholder="username">
																	</div>
															  
																	
																	<div class="info"></div>
																	<center>	<button type="submit" class="btn btn-info">recover</button></center>
						
											</form>
									</div>
				<div class="col-md-2">
				</div>
									
								</div>	
<center><p class="topspace"> Have an account with us? <a href="index.php">Login</a></p></center>								
					</div>
				</div>
						
	


				<div class="col-md-2">

				
				</div>	
					
		  </div>
    </div>
<br/><br/><br/><br/><br/><br/><br/><br/>
<section id="bottom" class="main">
    <!--Container-->
    <div class="container">

       
        <div class="row-fluid">

           
            <div class="col-md-3">
                <h4>medical Council of Malawi</h4>
                     <ul class="arrow">
                        <li><a href="">About Us</a></li>
                        <li><a href="#">Terms of Use</a></li>
                        <li><a href="#">Copyright</a></li>
                        <li><a href="#">News</a></li>

                    </ul>              
            </div>
          

           
            <div id="" class="col-md-3">
 
            </div>
       
            <div id="" class="col-md-3">
             
                <div>

                </div>
            </div>
        

            <div class="col-md-3">
            
            

        </div>

    </div>
   
</div>


</section>
<footer>

		<p>
		<div class="span5">
               <p> © 2017 <a target="_blank" href="" title="Medical council of Malawi">Medical council of Malawi</a>. All Rights Reserved.</p>
            </div>
			
		</p>

	</footer>
    <!-- Placed at the end of the document so the pages load faster -->
	<!-- start: JavaScript-->

	<script src="media/js/jquery.js"></script>
		<script src="media/js/bootstrap.min.js"></script>
		<!--table--->
		 <script src="media/js/jquery-1.7.2.min.js"></script>			
		 <script type="text/javascript" charset="utf-8" language="javascript" src="media/js/jquery.dataTables.js"></script>
		<script type="text/javascript" charset="utf-8" language="javascript" src="media/js/DT_bootstrap.js"></script>
				<script type="text/javascript">
$(document).ready(function (e) {
	$("#recover").on('submit',(function(e) {
		e.preventDefault();
		$.ajax({
        	url: "controller/recover.php",
			type: "POST",
			data:  new FormData(this),
			contentType: false,
    	    cache: false,
			processData:false,
				beforeSend: function() 
			{
				$(".info").html('<center><img class="gifi" src="media/images/loader.gif" alt="Loading...." align="absmiddle" title="Loading...."/></center>');
			},
			success: function(data)
		    {
			$(".info").fadeIn(5000).html(data);
	
		    },
		  	error: function() 
	    	{
	    	} 	        
	   });
	}));
});
</script>
	<!-- end: JavaScript-->

  </body>
</html>
