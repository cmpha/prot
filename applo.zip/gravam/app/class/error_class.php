<?php

class ERROR_pro
{


	 public function report_error($msg)
	 { 
	   	$logfile='log.txt';
		
			if( $handle=fopen($logfile,'a'))
				{
					$timestamp=strftime("%Y-%m-%d %H:%M:%S",time());
					$content="Error date: ".$timestamp. "\n" .$msg. "\n";
					
					fwrite($handle,$content);
					fclose($handle);
					
				
				}
			else{
					
				}
	 }
}
?>