<?php
include_once 'DB_class.php';
include_once 'error_class.php';
class SECURITY
{
	 
public function login($username,$password)
	 {
		try{
					$pdo = Database::connect();
					$db_email = "";
					$db_password = "";
					$d_status= "approved";
					$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
					$sql = "SELECT * FROM users WHERE username = ? AND password= ? AND status= ?";
					$q = $pdo->prepare($sql);
					$q->execute(array($username,$password,$d_status));
					$row= $q->fetch(PDO::FETCH_ASSOC);			
						$user_id = $row["user_id"];
						$db_username = $row["username"];
						$role = $row["role"];
						if($row >0){
										 if($role=='admin')
											{
												session_start();
												session_regenerate_id();
												$_SESSION["user_id"]=$user_id;
												$_SESSION["username"]= $db_username;
												$_SESSION["role"]= $role;
												echo '
												<script type="text/javascript">
												window.location = "admin/index.php"
												session_write_close();
												</script> ';
												
											}
										else
											{
												session_start();
												session_regenerate_id();
												$_SESSION["user_id"]=$user_id;
												$_SESSION["username"]=  $db_username;
												$_SESSION["role"]= $role;
												echo '
												<script type="text/javascript">
												window.location = "users/index.php"
												session_write_close();
												</script> ';
											}
										
								   }		  
						else       {
					
									echo '<div class="alert alert-danger">
											  <strong>Wrong password or username</strong>
											</div>';
								   }
					Database::disconnect();
				}
		 
		 catch(PDOException $e)
			{
				    $error= new  ERROR_pro();
					$msg="MSG: Error has occured. call admin!\nfile:". $e->getFile()."\non line:".$e->getLine()."\n\n";
					$error->report_error($msg);				
		
			} 
		 
	}
	
}

?>