<?php
include_once 'DB_class.php';
include_once 'error_class.php';

class SYSTEM_CLASS
{
		
		
	 public function create_user($first_name,$last_name,$username,$password,$email,$role,$date,$status)
		{ 
		  try{
						$pdo = Database::connect();
						$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
						$sql = "INSERT INTO users(first_name,last_name,username,password,email,role,date,status) 
						VALUES(:first_name,:last_name,:username,:password,:email,:role,:date,:status)";
						$statement = $pdo->prepare($sql);
						$statement->bindParam(':first_name', $first_name, PDO::PARAM_STR); 
						$statement->bindParam(':last_name', $last_name, PDO::PARAM_STR); 
						$statement->bindParam(':username', $username, PDO::PARAM_STR); 
						$statement->bindParam(':password', $password, PDO::PARAM_STR); 					
						$statement->bindParam(':email', $email, PDO::PARAM_STR); 
						$statement->bindParam(':role', $role, PDO::PARAM_STR); 
						$statement->bindParam(':date', $date, PDO::PARAM_STR);
						$statement->bindParam(':status', $status, PDO::PARAM_STR);
						$statement->execute();
						$feedback = ($statement)? true:false;
						return $feedback;
						Database::disconnect();					
			  }
		 catch(PDOException $e)
			  {
				    $error= new  ERROR_pro();

					$msg="MSG: Error has occured. call admin! \n file:". $e->getFile(). "\n on line:" .$e->getLine()."\n \n";
					$error->report_error($msg);
					$customError="fatal error, call suport";
					echo"$customError";
					
			  } 
		}

		public function new_document($document_name,$location,$type,$folder_id,$date,$visibility,$status,$user_id)
		{ 
 
		  try {
						$pdo = Database::connect();
						$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
						$sql = "INSERT INTO documents(document_name,location,type,folder_id,date,visibility,status,user_id) VALUES(:document_name,:location,:type,:folder_id,:date,:visibility,:status,:user_id)";
						$statement = $pdo->prepare($sql);
						$statement->bindParam(':document_name', $document_name, PDO::PARAM_STR); 
						$statement->bindParam(':location', $location, PDO::PARAM_STR); 
						$statement->bindParam(':type', $type, PDO::PARAM_STR); 
						$statement->bindParam(':folder_id', $folder_id, PDO::PARAM_STR); 
						$statement->bindParam(':date', $date, PDO::PARAM_STR); 
						$statement->bindParam(':visibility', $visibility, PDO::PARAM_STR); 
						$statement->bindParam(':status', $status, PDO::PARAM_STR); 
						$statement->bindParam(':user_id', $user_id, PDO::PARAM_STR); 
						$statement->execute();
						$feedback = ($statement)? true:false;
						return $feedback;
						Database::disconnect();						
			  }
		 catch(PDOException $e)
			  {
				    $error= new  ERROR_pro();

					$msg="MSG: Error has occured. call admin! \n file:". $e->getFile(). "\n on line:" .$e->getLine()."\n \n";
					$error->report_error($msg);
					$customError="fatal error, call suport";
					echo"$customError";				
						
			  } 
		}		
public function update_user($first_name,$last_name,$username,$password,$email,$role,$date,$status,$user_id)
	   {
			try{
		  
					$pdo = Database::connect();  
					$query = "UPDATE users set first_name = ?,last_name = ?, username = ?, password = ?, email = ?,role = ?, date = ?,status=? WHERE user_id = ?";  
					$stmt = $pdo->prepare( $query );
					$stmt->execute(array($first_name,$last_name,$username,$password,$email,$role,$date,$status,$user_id));
					return $stmt;
				}
				
		 catch(PDOException $e)
			  {
				    $error= new  ERROR_pro();
					$msg="MSG: Error has occured. call admin!\nfile:". $e->getFile()."\non line:".$e->getLine()."\n\n";
					$error->report_error($msg);					
			  } 			
		}

public function update_us($status,$user_id,$role)
	   {
			try{
		  
					$pdo = Database::connect();  
					$query = "UPDATE users set status=?, role=? WHERE user_id = ?";  
					$stmt = $pdo->prepare( $query );
					$stmt->execute(array($status,$role,$user_id));
					return $stmt;
				}
				
		 catch(PDOException $e)
			  {
				    $error= new  ERROR_pro();
					$msg="MSG: Error has occured. call admin!\nfile:". $e->getFile()."\non line:".$e->getLine()."\n\n";
					$error->report_error($msg);					
			  } 			
		}
		
public function update_recovery($first_name,$last_name,$email,$username,$password,$id)
	   {
			try{
		  
					$pdo = Database::connect();  
					$query = "UPDATE doctors set first_name = ?,last_name = ?, email= ?,username=?,password=? WHERE doctor_id = ?";  
					$stmt = $pdo->prepare( $query );
					$stmt->execute(array($first_name,$last_name,$email,$username,$password,$id));
					return $stmt;
				}
				
		 catch(PDOException $e)
			  {
				    $error= new  ERROR_pro();
					$msg="MSG: Error has occured. call admin!\nfile:". $e->getFile()."\non line:".$e->getLine()."\n\n";
					$error->report_error($msg);					
			  } 			
		}	
		
public function convertDate($str)
	   {
			try{
		  
				$newdate =date('dS M Y',strtotime($str));
				return $newdate;
				}
				
		 catch(PDOException $e)
			  {
				    $error= new  ERROR_pro();
					$msg="MSG: Error has occured. call admin!\nfile:". $e->getFile()."\non line:".$e->getLine()."\n\n";
					$error->report_error($msg);					
			  } 			
		}	
public function update_code($code,$status)
	   {
			try{
		  
					$pdo = Database::connect();  
					$query = "UPDATE recovery set status = ? WHERE code = ?";  
					$stmt = $pdo->prepare( $query );
					$stmt->execute(array($status,$code));
					return $stmt;
				}
				
		 catch(PDOException $e)
			  {
				    $error= new  ERROR_pro();
					$msg="MSG: Error has occured. call admin!\nfile:". $e->getFile()."\non line:".$e->getLine()."\n\n";
					$error->report_error($msg);					
			  } 			
		}	
	    public function GetrecoveryInfo($code,$date,$status)
		   {
              try{
				$pdo = Database::connect();
				$query = "SELECT COUNT(recovery.doctor_id) AS total, doctors.doctor_id, doctors.email, doctors.first_name, doctors.last_name, doctors.username
							FROM doctors, recovery
							WHERE recovery.code = ?
							AND recovery.doctor_id = doctors.doctor_id
							AND recovery.date = ?
							AND recovery.status = ?";  
				$stmt = $pdo->prepare( $query );
				$stmt->execute(array($code,$date,$status));
				return $stmt;
				 }
			 catch(PDOException $e)
				 {
				    $error= new  ERROR_pro();
					$msg="MSG: Error has occured. call admin!\nfile:". $e->getFile()."\non line:".$e->getLine()."\n\n";
					$error->report_error($msg);					
			     }
           }		   
		








		
		
public function update_event($event_id,$status)
	   {
			try{
		  
					$pdo = Database::connect();  
					$query = "UPDATE events set status = ? WHERE event_id = ?";  
					$stmt = $pdo->prepare( $query );
					$stmt->execute(array($status,$event_id));
					return $stmt;
				}
				
		 catch(PDOException $e)
			  {
				    $error= new  ERROR_pro();
					$msg="MSG: Error has occured. call admin!\nfile:". $e->getFile()."\non line:".$e->getLine()."\n\n";
					$error->report_error($msg);					
			  } 			
		}
		
	    public function getUsers()
		   {
              try{
				$pdo = Database::connect();
				$query = "SELECT * FROM users";  
				$stmt = $pdo->prepare( $query );
				$stmt->execute();
				return $stmt;
				 }
			 catch(PDOException $e)
				 {
				    $error= new  ERROR_pro();
					$msg="MSG: Error has occured. call admin!\nfile:". $e->getFile()."\non line:".$e->getLine()."\n\n";
					$error->report_error($msg);					
			     }
           }
		   
	    public function getUserByID($user_id)
		   {
              try{
				$pdo = Database::connect();
				$query = "SELECT * FROM users WHERE user_id=?";  
				$stmt = $pdo->prepare( $query );
				$stmt->execute(array($user_id));
				return $stmt;
				 }
			 catch(PDOException $e)
				 {
				    $error= new  ERROR_pro();
					$msg="MSG: Error has occured. call admin!\nfile:". $e->getFile()."\non line:".$e->getLine()."\n\n";
					$error->report_error($msg);					
			     }
           }

	    public function getUsersByID($id)
		   {
              try{
				$pdo = Database::connect();
				$query = "SELECT * FROM users WHERE users.user_id=?";  
				$stmt = $pdo->prepare( $query );
				$stmt->execute(array($id));
				return $stmt;
				 }
			 catch(PDOException $e)
				 {
				    $error= new  ERROR_pro();
					$msg="MSG: Error has occured. call admin!\nfile:". $e->getFile()."\non line:".$e->getLine()."\n\n";
					$error->report_error($msg);					
			     }
           }

	    public function GetthisFile($document_name)
		   {
              try{
				$pdo = Database::connect();
				$query = "SELECT COUNT(document_id) AS total FROM documents WHERE document_name=?";  
				$stmt = $pdo->prepare( $query );
				$stmt->execute(array($document_name));
				return $stmt;
				 }
			 catch(PDOException $e)
				 {
				    $error= new  ERROR_pro();
					$msg="MSG: Error has occured. call admin!\nfile:". $e->getFile()."\non line:".$e->getLine()."\n\n";
					$error->report_error($msg);					
			     }
           }
		   
		   
		   
	    public function GetPendingusers($sts)
		   {
              try{
				$pdo = Database::connect();
				$query = "SELECT * FROM users WHERE status=?";  
				$stmt = $pdo->prepare( $query );
				$stmt->execute(array($sts));
				return $stmt;
				 }
			 catch(PDOException $e)
				 {
				    $error= new  ERROR_pro();
					$msg="MSG: Error has occured. call admin!\nfile:". $e->getFile()."\non line:".$e->getLine()."\n\n";
					$error->report_error($msg);					
			     }
           }		   
			public function getdocByID($id)
				   {
					  try{
							$pdo = Database::connect();
							$query = "SELECT * FROM documents,folders,users WHERE folders.folder_id=documents.folder_id
							AND documents.user_id=users.user_id AND  document_id=?";  
							$stmt = $pdo->prepare( $query );
							$stmt->execute(array($id));
							return $stmt;
						 }
					 catch(PDOException $e)
						 {
							$error= new  ERROR_pro();
							$msg="MSG: Error has occured. call admin!\nfile:". $e->getFile()."\non line:".$e->getLine()."\n\n";
							$error->report_error($msg);					
						 }
				   }		
	    public function getDocsByfolder($visibilityexception,$folder_id)
		   {
              try{
				$pdo = Database::connect();
				$query = "SELECT * FROM documents,folders,users WHERE folders.folder_id=documents.folder_id
							AND documents.user_id=users.user_id AND visibility !=?
							AND documents.folder_id= ?
							";  
				$stmt = $pdo->prepare( $query );
				$stmt->execute(array($visibilityexception,$folder_id));
				return $stmt;
				 }
			 catch(PDOException $e)
				 {
				    $error= new  ERROR_pro();
					$msg="MSG: Error has occured. call admin!\nfile:". $e->getFile()."\non line:".$e->getLine()."\n\n";
					$error->report_error($msg);					
			     }
           }		
	    public function getDocs($visibilityexception)
		   {
              try{
				$pdo = Database::connect();
				$query = "SELECT * FROM documents,folders,users WHERE folders.folder_id=documents.folder_id
							AND documents.user_id=users.user_id AND visibility !=?
							";  
				$stmt = $pdo->prepare( $query );
				$stmt->execute(array($visibilityexception));
				return $stmt;
				 }
			 catch(PDOException $e)
				 {
				    $error= new  ERROR_pro();
					$msg="MSG: Error has occured. call admin!\nfile:". $e->getFile()."\non line:".$e->getLine()."\n\n";
					$error->report_error($msg);					
			     }
           }	

	    public function getmyDocs($visibilityexception,$user_id)
		   {
              try{
				$pdo = Database::connect();
				$query = "SELECT * FROM documents,users,folders WHERE folders.folder_id=documents.folder_id AND
							documents.user_id=?
							AND documents.user_id=users.user_id
							AND visibility !=?
							";  
				$stmt = $pdo->prepare( $query );
				$stmt->execute(array($user_id,$visibilityexception));
				return $stmt;
				 }
			 catch(PDOException $e)
				 {
				    $error= new  ERROR_pro();
					$msg="MSG: Error has occured. call admin!\nfile:". $e->getFile()."\non line:".$e->getLine()."\n\n";
					$error->report_error($msg);					
			     }
           }	


	    public function getnoti($view,$user_id)
		   {
              try{
				$pdo = Database::connect();
				$query = "SELECT COUNT(shares.document_id) as total,users.username,shares.document_id,document_name,shares.dateshared  FROM shares,documents,users WHERE 
							shares.user_id=? 
							AND documents.user_id=users.user_id
							AND shares.document_id=documents.document_id
							AND view=?
							
							";  
				$stmt = $pdo->prepare( $query );
				$stmt->execute(array($user_id,$view));
				return $stmt;
				 }
			 catch(PDOException $e)
				 {
				    $error= new  ERROR_pro();
					$msg="MSG: Error has occured. call admin!\nfile:". $e->getFile()."\non line:".$e->getLine()."\n\n";
					$error->report_error($msg);					
			     }
           }	
		   
		   
		   
		   



	    public function getmysharedDocs($visibilityexception,$user_id)
		   {
              try{
				$pdo = Database::connect();
				$query = "SELECT * FROM documents,shares,users,folders WHERE folders.folder_id=documents.folder_id AND
							documents.user_id=?
							AND shares.document_id=documents.document_id 
							AND shares.user_id =?
							AND documents.user_id=users.user_id
							AND visibility !=?
							
							";  
				$stmt = $pdo->prepare( $query );
				$stmt->execute(array($user_id,$user_id,$visibilityexception));
				return $stmt;
				 }
			 catch(PDOException $e)
				 {
				    $error= new  ERROR_pro();
					$msg="MSG: Error has occured. call admin!\nfile:". $e->getFile()."\non line:".$e->getLine()."\n\n";
					$error->report_error($msg);					
			     }
           }			   
		   
	    public function delete_stuff($id,$column,$table)
		   {
              try{
					$pdo = Database::connect();
					$query = "DELETE FROM $table WHERE $column = ?";  
					$stmt = $pdo->prepare( $query );
					$stmt->execute(array($id));
					return $stmt;
				 }
			 catch(PDOException $e)
				 {
				    $error= new  ERROR_pro();
					$msg="MSG: Error has occured. call admin!\nfile:". $e->getFile()."\non line:".$e->getLine()."\n\n";
					$error->report_error($msg);					
			     }
           }
		   
	    public function approve($user_id,$status)
		   {
              try{
					$pdo = Database::connect();
					$query = "UPDATE users SET status=? WHERE user_id=?";  
					$stmt = $pdo->prepare( $query );
					$stmt->execute(array($status,$user_id));
					return $stmt;
				 }
			 catch(PDOException $e)
				 {
				    $error= new  ERROR_pro();
					$msg="MSG: Error has occured. call admin!\nfile:". $e->getFile()."\non line:".$e->getLine()."\n\n";
					$error->report_error($msg);					
			     }
           }


		
	
		 /*public function delete_page($page_id)
		   {
              try{
					$pdo = Database::connect();
					$query = "DELETE FROM pages WHERE page_id = ?";  
					$stmt = $pdo->prepare( $query );
					$stmt->execute(array($page_id));
					return $stmt;
				 }
			 catch(PDOException $e)
				 {
				    $error= new  ERROR_pro();
					$msg="MSG: Error has occured. call admin!\nfile:". $e->getFile()."\non line:".$e->getLine()."\n\n";
					$error->report_error($msg);					
			     }
           }
		*/


	
		
			
	public function create_folder($folder_name,$date) 
		{ 
 
		  try {
						$pdo = Database::connect();
						$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
						$sql = "INSERT INTO folders(folder_name,date) VALUES(:folder_name,:date)";
						$statement = $pdo->prepare($sql);
						$statement->bindParam(':folder_name', $folder_name, PDO::PARAM_STR); 
						$statement->bindParam(':date', $date, PDO::PARAM_STR); 
						$statement->execute();
						$feedback = ($statement)? true:false;
						return $feedback;
						Database::disconnect();						
				}
		 catch(PDOException $e)
			   {
							$error= new  ERROR_pro();
							$msg="MSG: Error has occured. call admin!\nfile:". $e->getFile()."\non line:".$e->getLine()."\n\n";
							$error->report_error($msg);					
						
			   } 
		}

	public function share($document_id,$user_id,$notes,$status,$view,$date,$owner) 
		{ 
 
		  try {
						$pdo = Database::connect();
						$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
						$sql = "INSERT INTO shares(document_id,user_id,notes,status,view,dateshared,owner) VALUES(:document_id,:user_id,:notes,:status,:view,:dateshared,:owner)";
						$statement = $pdo->prepare($sql);
						$statement->bindParam(':document_id', $document_id, PDO::PARAM_STR); 
						$statement->bindParam(':user_id', $user_id, PDO::PARAM_STR); 
						$statement->bindParam(':notes', $notes, PDO::PARAM_STR);
						$statement->bindParam(':status', $status, PDO::PARAM_STR);
                        $statement->bindParam(':view', $view, PDO::PARAM_STR); 
						$statement->bindParam(':dateshared', $date, PDO::PARAM_STR);
						$statement->bindParam(':owner', $owner, PDO::PARAM_STR);						
						$statement->execute();
						$feedback = ($statement)? true:false;
						return $feedback;
						Database::disconnect();						
				}
		 catch(PDOException $e)
			   {
							$error= new  ERROR_pro();
							$msg="MSG: Error has occured. call admin!\nfile:". $e->getFile()."\non line:".$e->getLine()."\n\n";
							$error->report_error($msg);					
						
			   } 
		}
		
	public function recover($code,$date,$status,$id) 
		{ 
 
		  try {
						$pdo = Database::connect();
						$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
						$sql = "INSERT INTO recovery(code,date,status,doctor_id) VALUES(:code,:date,:status,:doctor_id)";
						$statement = $pdo->prepare($sql);
						$statement->bindParam(':code', $code, PDO::PARAM_STR); 
						$statement->bindParam(':date', $date, PDO::PARAM_STR); 
						$statement->bindParam(':status', $status, PDO::PARAM_STR); 
						$statement->bindParam(':doctor_id', $id, PDO::PARAM_STR); 
						$statement->execute();
						$feedback = ($statement)? true:false;
						return $feedback;
						Database::disconnect();						
				}
		 catch(PDOException $e)
			   {
							$error= new  ERROR_pro();
							$msg="MSG: Error has occured. call admin!\nfile:". $e->getFile()."\non line:".$e->getLine()."\n\n";
							$error->report_error($msg);					
						
			   } 
		}		
	public function create_group($us_name) 
		{ 
 
		  try {
						$pdo = Database::connect();
						$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
						$sql = "INSERT INTO user_groups(us_name) VALUES(:us_name)";
						$statement = $pdo->prepare($sql);
						$statement->bindParam(':us_name', $us_name, PDO::PARAM_STR); 
						$statement->execute();
						$feedback = ($statement)? true:false;
						return $feedback;
						Database::disconnect();						
				}
		 catch(PDOException $e)
			   {
							$error= new  ERROR_pro();
							$msg="MSG: Error has occured. call admin!\nfile:". $e->getFile()."\non line:".$e->getLine()."\n\n";
							$error->report_error($msg);					
						
			   } 
		}
			public function geteventForUser($doctor_id)
				   {
					  try{
							$pdo = Database::connect();
							$query = "SELECT * FROM events,event_type WHERE event_type.type_id=events.type_id AND events.doctor_id = ?";  
							$stmt = $pdo->prepare( $query );
							$stmt->execute(array($doctor_id));
							return $stmt;
						 }
					 catch(PDOException $e)
						 {
							$error= new  ERROR_pro();
							$msg="MSG: Error has occured. call admin!\nfile:". $e->getFile()."\non line:".$e->getLine()."\n\n";
							$error->report_error($msg);					
						 }
				   }


			public function getFolders()
				   {
					  try{
							$pdo = Database::connect();
							$query = "SELECT * FROM  folders ORDER BY folder_id ASC";  
							$stmt = $pdo->prepare( $query );
							$stmt->execute();
							return $stmt;
						 }
					 catch(PDOException $e)
						 {
							$error= new  ERROR_pro();
							$msg="MSG: Error has occured. call admin!\nfile:". $e->getFile()."\non line:".$e->getLine()."\n\n";
							$error->report_error($msg);					
						 }
				   }
				   
			public function getyear()
				   {
					  try{
							$pdo = Database::connect();
							$query = "SELECT YEAR(events.date) AS  year FROM events GROUP BY year";  
							$stmt = $pdo->prepare( $query );
							$stmt->execute();
							return $stmt;
						 }
					 catch(PDOException $e)
						 {
							$error= new  ERROR_pro();
							$msg="MSG: Error has occured. call admin!\nfile:". $e->getFile()."\non line:".$e->getLine()."\n\n";
							$error->report_error($msg);					
						 }
				   }
				   
			public function getEventByYr($year)
				   {
					  try{
							$pdo = Database::connect();
							$query = "SELECT YEAR(events.date) AS year,events.event_id,events.name,events.description,events.score,events.date,doctors.doctor_id,doctors.first_name,doctors.last_name,event_type.type_id,event_type.type_name,event_type.abbre
										FROM doctors,event_type,events
										WHERE events.doctor_id=doctors.doctor_id
										AND events.type_id=event_type.type_id
										AND YEAR(events.date)='$year'";  
							$stmt = $pdo->prepare( $query );
							$stmt->execute();
							return $stmt;
						 }
					 catch(PDOException $e)
						 {
							$error= new  ERROR_pro();
							$msg="MSG: Error has occured. call admin!\nfile:". $e->getFile()."\non line:".$e->getLine()."\n\n";
							$error->report_error($msg);					
						 }
				   }
				   
			public function getEvents()
				   {
					  try{
							$pdo = Database::connect();
							$query = "SELECT events.status,events.date,events.event_id,events.name,events.description,events.score,events.date,doctors.doctor_id,doctors.first_name,doctors.last_name,event_type.type_id,event_type.type_name,event_type.abbre
										FROM doctors,event_type,events
										WHERE events.doctor_id=doctors.doctor_id
										AND events.type_id=event_type.type_id ";  
							$stmt = $pdo->prepare( $query );
							$stmt->execute();
							return $stmt;
						 }
					 catch(PDOException $e)
						 {
							$error= new  ERROR_pro();
							$msg="MSG: Error has occured. call admin!\nfile:". $e->getFile()."\non line:".$e->getLine()."\n\n";
							$error->report_error($msg);					
						 }
				   }
				   
				   
			public function getEventByIdAll($event_id)
				   {
					  try{
							$pdo = Database::connect();
							$query = "SELECT organisations.org_name,organisations.abbre, events.date,events.event_id,events.name,events.description,events.score,events.date,doctors.doctor_id,doctors.first_name,doctors.last_name,event_type.type_id,event_type.type_name,event_type.abbre
										FROM doctors,event_type,events,organisations
										WHERE events.doctor_id=doctors.doctor_id
										AND organisations.org_id=doctors.org_id
										AND events.type_id=event_type.type_id
										AND events.event_id='$event_id'";  
							$stmt = $pdo->prepare( $query );
							$stmt->execute();
							return $stmt;
						 }
					 catch(PDOException $e)
						 {
							$error= new  ERROR_pro();
							$msg="MSG: Error has occured. call admin!\nfile:". $e->getFile()."\non line:".$e->getLine()."\n\n";
							$error->report_error($msg);					
						 }
				   }				   
			public function holyQuery()
				   {
					  try{
							$pdo = Database::connect();
							$query = 'SELECT
											YEAR(events.date) AS  year,
											SUM(CASE WHEN event_type.abbre="A" AND events.type_id=event_type.type_id 
											AND events.doctor_id=doctors.doctor_id  THEN events.score ELSE 0 END) AS A,
											SUM(CASE WHEN event_type.abbre="B" AND events.type_id=event_type.type_id
											AND events.doctor_id=doctors.doctor_id THEN events.score ELSE 0 END) AS B,
											SUM(CASE WHEN event_type.abbre="C" AND events.type_id=event_type.type_id
											 AND events.doctor_id=doctors.doctor_id THEN events.score ELSE 0 END) AS C,
											SUM(CASE WHEN event_type.abbre="D" AND events.type_id=event_type.type_id
											 AND events.doctor_id=doctors.doctor_id THEN events.score ELSE 0 END) AS D,
											SUM(CASE WHEN event_type.abbre="E" AND events.type_id=event_type.type_id
											 AND events.doctor_id=doctors.doctor_id THEN events.score ELSE 0 END) AS E,
											SUM(CASE WHEN event_type.abbre="F" AND events.type_id=event_type.type_id 
											 AND events.doctor_id=doctors.doctor_id THEN events.score ELSE 0 END) AS F,
											SUM(CASE WHEN event_type.abbre="G" AND events.type_id=event_type.type_id
											 AND events.doctor_id=doctors.doctor_id THEN events.score ELSE 0 END) AS G,
											SUM(CASE WHEN event_type.abbre="H" AND events.type_id=event_type.type_id
											 AND events.doctor_id=doctors.doctor_id THEN events.score ELSE 0 END) AS H,
											SUM(CASE WHEN event_type.abbre="I" AND events.type_id=event_type.type_id
											 AND events.doctor_id=doctors.doctor_id THEN events.score ELSE 0 END) AS I,
											SUM(CASE WHEN event_type.abbre="X" AND events.type_id=event_type.type_id 
											AND events.doctor_id=doctors.doctor_id THEN events.score ELSE 0 END) AS X,
											SUM(CASE WHEN events.type_id=event_type.type_id AND events.doctor_id=doctors.doctor_id THEN events.score ELSE 0 END)
											 AS Total
											FROM events,event_type,doctors
											GROUP BY
											year
											';  
							$stmt = $pdo->prepare( $query );
							$stmt->execute();
							return $stmt;
						 }
					 catch(PDOException $e)
						 {
							$error= new  ERROR_pro();
							$msg="MSG: Error has occured. call admin!\nfile:". $e->getFile()."\non line:".$e->getLine()."\n\n";
							$error->report_error($msg);					
						 }
				   }				   
			public function geteventByID($event_id)
				   {
					  try{
							$pdo = Database::connect();
							$query = "SELECT * FROM events WHERE event_id = ?";  
							$stmt = $pdo->prepare( $query );
							$stmt->execute(array($event_id));
							return $stmt;
						 }
					 catch(PDOException $e)
						 {
							$error= new  ERROR_pro();
							$msg="MSG: Error has occured. call admin!\nfile:". $e->getFile()."\non line:".$e->getLine()."\n\n";
							$error->report_error($msg);					
						 }
				   }

			public function getStuff($table)
				   {
					  try{
							$pdo = Database::connect();
							$query = "SELECT * FROM $table";  
							$stmt = $pdo->prepare( $query );
							$stmt->execute();
							return $stmt;
						 }
					 catch(PDOException $e)
						 {
							$error= new  ERROR_pro();
							$msg="MSG: Error has occured. call admin!\nfile:". $e->getFile()."\non line:".$e->getLine()."\n\n";
							$error->report_error($msg);					
						 }
				   }
				   
			public function checkMail($email)
				   {
					  try{
							$pdo = Database::connect();
							$query = "SELECT COUNT(doctor_id) AS total ,doctor_id FROM doctors WHERE email= ?";  
							$stmt = $pdo->prepare( $query );
							$stmt->execute(array($email));
							return $stmt;
						 }
					 catch(PDOException $e)
						 {
							$error= new  ERROR_pro();
							$msg="MSG: Error has occured. call admin!\nfile:". $e->getFile()."\non line:".$e->getLine()."\n\n";
							$error->report_error($msg);					
						 }
				   }				   
									
public function is_date_time_valid($date)
	{
			if(date('Y-m-d H:i:s',strtotime($date))==$date){
			 return TRUE;
			 }
			 else{
			 return FALSE;
			 }
	}
 
 public function time_ago($date)
	{
      $check=new SYSTEM_CLASS();
			$is_valid = $check->is_date_time_valid($date);

			if ($is_valid) {

			$timestamp = strtotime($date);

			$difference = time() - $timestamp;

			$periods = array("sec", "min", "hour", "day", "week", "month", "year", "decade");

			$lengths = array("60", "60", "24", "7", "4.35", "12", "10");

			 

			if ($difference > 0) { // this was in the past time

			$ending = "ago";

			} 
			else { // this was in the future time

			$difference = -$difference;

			$ending = "just now";

			}

			for ($j = 0; $difference >= $lengths[$j]; $j++)

			$difference /= $lengths[$j];

			$difference = round($difference);

			if ($difference != 1)

			$periods[$j].= "s";

			$text = "$difference $periods[$j] $ending";

			return $text;

			}else {

			return 'Date Time must be in "yyyy-mm-dd hh:mm:ss" format';

			}

	}
	
	
	
				public function getOrgDemographics()
				   {
					  try{
							$pdo = Database::connect();
							$query = "SELECT COUNT( documents.document_id ) AS total, folders.folder_name
										FROM documents, folders
										WHERE folders.folder_id = documents.folder_id
										GROUP BY folders.folder_id";  
							$stmt = $pdo->prepare( $query );
							$stmt->execute();
							return $stmt;
						 }
					 catch(PDOException $e)
						 {
							$error= new  ERROR_pro();
							$msg="MSG: Error has occured. call admin!\nfile:". $e->getFile()."\non line:".$e->getLine()."\n\n";
							$error->report_error($msg);					
						 }
				   }


				public function Counttable($table,$column)
				   {
					  try{
							$pdo = Database::connect();
							$query = "SELECT COUNT($column) AS total
										FROM $table
										";  
							$stmt = $pdo->prepare( $query );
							$stmt->execute();
							return $stmt;
						 }
					 catch(PDOException $e)
						 {
							$error= new  ERROR_pro();
							$msg="MSG: Error has occured. call admin!\nfile:". $e->getFile()."\non line:".$e->getLine()."\n\n";
							$error->report_error($msg);					
						 }
				   }

				public function Sumtable($table,$column)
				   {
					  try{
							$pdo = Database::connect();
							$query = "SELECT SUM($column) AS total
										FROM $table
										";  
							$stmt = $pdo->prepare( $query );
							$stmt->execute();
							return $stmt;
						 }
					 catch(PDOException $e)
						 {
							$error= new  ERROR_pro();
							$msg="MSG: Error has occured. call admin!\nfile:". $e->getFile()."\non line:".$e->getLine()."\n\n";
							$error->report_error($msg);					
						 }
				   }

				public function Statustable($status)
				   {
					  try{
							$pdo = Database::connect();
							$query = "SELECT COUNT(doctor_id) AS total 
										FROM doctors WHERE status=?
										
										";  
							$stmt = $pdo->prepare( $query );
							$stmt->execute(array($status));
							return $stmt;
						 }
					 catch(PDOException $e)
						 {
							$error= new  ERROR_pro();
							$msg="MSG: Error has occured. call admin!\nfile:". $e->getFile()."\non line:".$e->getLine()."\n\n";
							$error->report_error($msg);					
						 }
				   }


		  public function countevents()
			   {
				  try{
						$pdo = Database::connect();
						$query = "select count(*) \"total\"  from events";  
						$stmt = $pdo->prepare( $query );
						$stmt->execute();
						return $stmt;
					 }
				 catch(PDOException $e)
					 {
						$error= new  ERROR_pro();
						$msg="MSG: Error has occured. call admin!\nfile:". $e->getFile()."\non line:".$e->getLine()."\n\n";
						$error->report_error($msg);					
					 }
		   }
		   
			public function getPagevents($k,$dis)
				   {
						  try{
								$pdo = Database::connect();
								$query = "SELECT events.event_id, events.status,events.date,events.event_id,events.name,events.description,events.score,events.date,doctors.doctor_id,doctors.first_name,doctors.last_name,event_type.type_id,event_type.type_name,event_type.abbre
										FROM doctors,event_type,events
										WHERE events.doctor_id=doctors.doctor_id
										AND events.type_id=event_type.type_id ORDER BY events.event_id DESC LIMIT $k,$dis";  
								$stmt = $pdo->prepare( $query );
								$stmt->execute();
								return $stmt;
							 }
						 catch(PDOException $e)
							 {
								$error= new  ERROR_pro();
								$msg="MSG: Error has occured. call admin!\nfile:". $e->getFile()."\non line:".$e->getLine()."\n\n";
								$error->report_error($msg);		
							 }
					}

				   
}

?>