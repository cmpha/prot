<?php

include_once 'DB_class.php';
class SET_UP
{
		
		
			
			public function create_table1()
				{
              
					$pdo = Database::connect();
					$query1 = "
CREATE TABLE `employees` (
	`employee_id` INT(20) NOT NULL AUTO_INCREMENT ,
	`first_name` VARCHAR(50) NOT NULL,
	`last_name` VARCHAR(50) NOT NULL,
	`username` VARCHAR(50) NOT NULL,
	`gender` VARCHAR(50) ,
	`phone_number` VARCHAR(50),
	`other_phone` VARCHAR(50),
	`password` VARCHAR(190) NOT NULL,
	`email` VARCHAR(50) ,
	`role` VARCHAR(50) NOT NULL,
	`start_date` date NOT NULL,
	`status` VARCHAR(50) NOT NULL,	
	PRIMARY KEY(employee_id)
		);
					";	
					$stmt = $pdo->prepare($query1);
					$stmt->execute();
					return $stmt;
				
				}
			public function create_table2()
				{
              
					$pdo = Database::connect();
					$query1 = "
						CREATE TABLE `folders` (
						`folder_id` INT(20) NOT NULL AUTO_INCREMENT ,
						`folder_name` VARCHAR(200) NOT NULL,
						`date` date NOT NULL,
						`employee_id` INT(20) NOT NULL,
						FOREIGN KEY (employee_id) REFERENCES employees(employee_id)ON DELETE CASCADE ON UPDATE CASCADE,
						PRIMARY KEY(folder_id)
						) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;		
					";	
					$stmt = $pdo->prepare($query1);
					$stmt->execute();
					return $stmt;
				
				}		
			public function create_table3()
				{
              
					$pdo = Database::connect();
					$query1 = "
						CREATE TABLE `documents` (
						`document_id` INT(20) NOT NULL AUTO_INCREMENT ,
						`document_name` VARCHAR(200) NOT NULL,
						`location` VARCHAR(200) NOT NULL,
						`folder_id` INT(20) NOT NULL,
						`date` date NOT NULL,
						`visibility` VARCHAR(30) NOT NULL,
						`status` VARCHAR(30) NOT NULL,
						`user_id` INT(20) NOT NULL,
						FOREIGN KEY (folder_id) REFERENCES folders(folder_id)ON DELETE CASCADE ON UPDATE CASCADE,
						FOREIGN KEY (user_id) REFERENCES users(user_id)ON DELETE CASCADE ON UPDATE CASCADE,
						PRIMARY KEY(document_id)
						) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;	
					";	
					$stmt = $pdo->prepare($query1);
					$stmt->execute();
					return $stmt;
				
				}
				
			public function create_table4()
				{
              
					$pdo = Database::connect();
					
					$query1 = "
						CREATE TABLE `shares` (
						`document_id` INT(20) NOT NULL,
						`user_id` INT(20) NOT NULL,
						`notes` VARCHAR(600) NOT NULL,
						`status` VARCHAR(30) NOT NULL,
						`view` VARCHAR(30) NOT NULL,
						`dateshared` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
						`owner` INT(20) NOT NULL,
						FOREIGN KEY (document_id) REFERENCES documents(document_id)ON DELETE CASCADE ON UPDATE CASCADE,
						FOREIGN KEY (user_id) REFERENCES users(user_id)ON DELETE CASCADE ON UPDATE CASCADE
				
						);			
					";
					
					
					$stmt = $pdo->prepare($query1 );
					$stmt->execute();
					return $stmt;
				
				}



	
}

?>