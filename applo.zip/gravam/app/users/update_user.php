<?php include('../include/header_user.php');?>




<div class="col-sm-10 col-sm-offset-3 col-md-10 col-md-offset-2 main">
     <ol class="breadcrumb ">
                  <li><a href="manage_users.php">Users</a></li>
                  <li class="active">User profile</li>
                </ol>
        
  <h3 class="page-header">Update  profile</h3>

							<div class="Cbox">
								<div class="row">
														<?php	 

						$id=$_GET['id'];
						$getUserData=$dbtask->getUsersByID($id);
						while($row=$getUserData->fetch(PDO::FETCH_ASSOC))
								{
								$user=$row['user_id'];
								$first_name=$row['first_name'];
								$last_name=$row['last_name'];
								$username=$row['username'];
								
								$role=$row['role'];
								$date=$row['date'];
								$email=$row['email'];
								$status=$row['status'];	
						
						
						?>
								<form  id="Upuser" class="fms" action="" method="post">
								<center><h4>Account details</h4></center>
									<div class="col-md-6">
									<input type="hidden" name="user_id" value="<?php echo $user; ?>">
										
										<input type="hidden" name="date" value="<?php echo $date; ?>">
													<div class="form-group">
														<label class="mylabel">First name</label>
														<input type="text" disabled="" name="first_name"class="form-control" value="<?php echo $first_name ?>">
													</div>
											  
													<div class="form-group">
													<label class="mylabel">Last name </label>
														<input type="text" disabled=""  name="last_name" class="form-control" value="<?php echo $last_name; ?>">
													</div>
													
													<div class="form-group">
														<label class="mylabel">username </label>
														<input type="text" disabled="" name="username" class="form-control" value="<?php echo $username; ?>">
													</div>
												

<br/>

																					<div class="control-group">
													  <label> Status</label>
													  <div class="controls">
														<select class="form-control" name="status">
															<option value="<?php echo $status;?>"><?php echo $status;?></option>
																															
														<option value="pending">Pending</option>
														<option value="approved">Approved</option>
														
														</select>
													  </div>
													</div>													
									</div>
					
										
									<div class="col-md-6">
											
						
													<div class="form-group">
														<label class="mylabel">Email </label>
														<input type="text" disabled="" name="email"class="form-control" value="<?php echo $email; ?>">
													</div>
											  
													<div class="form-group">
														<label class="mylabel">Password </label>
														<input type="password" disabled="" name="password" class="form-control" >
													</div>
													
<br/>

												<div class="form-group">
													  <label class="mylabel">Role</label>
													  <div class="controls">
														<select class="form-control" name="role">
															<option value="<?php echo $role;?>"><?php echo $role;?></option>
																															
														<option value="user">User</option>
														<option value="admin">Administrator</option>
														
														</select>
													  </div>
													</div>														
												
													
													<div class="info"></div>
													<center>	<button type="submit" class="btn btn-info">Update</button></center>
													
											
											
									</div>		
											
											
							</form>
							<?php }?>
								</div>	
								
					</div>		


<?php include('../include/admin_footer.php');?>