<?php include('../include/header_user.php');?>




<div class="col-sm-10 col-sm-offset-3 col-md-10 col-md-offset-2 main">
     <ol class="breadcrumb ">
                  <li><a href="index.php">Dashboard</a></li>
                  <li class="active">Administration</li>
                </ol>
        
						
				
			         <h3 class="page-header">Administration</h3> 
					 <div class="info"></div>
						<form id="approve" action="" method="post">
										 
										<table cellpadding="0" cellspacing="0" border="0" class="table table-striped table-bordered bootstrap-datatable datatable dataTable" id="example">
										  <thead>
											  <tr>
												  <th>First Name</th>
												  <th>Last Name</th>
												  <th>Username</th>
												  <th>Email</th>
												  <th>Date registered</th>
												  <th>Role</th>
												  <th>Status</th>
													<th>Permission</th>
												 
											  </tr>
										  </thead>   
										  <tbody>
										  
												<?php	 
												$sts="pending";
												$db_users=$dbtask->GetPendingusers($sts);
												while($row=$db_users->fetch(PDO::FETCH_ASSOC))
												{
													$user_id=$row['user_id'];
													$first_name=$row['first_name'];
													$last_name=$row['last_name'];
													$username=$row['username'];
													$password=$row['password'];
													$role=$row['role'];
													$date=$row['date'];
													$email=$row['email'];
													$status=$row['status'];

																				


												?>										  
											<tr>

												<td><?php echo $first_name;?></td>
												<td><?php echo $last_name;?></td>
												<td><?php echo $username;?></td>
												<td><?php echo $email;?></td>
												<td class="center"><?php echo $date;?></td>
												<td class="center"><?php echo $role;?></td>
												<td class="center">
													<span class="label label-red"><?php echo $status;?></span>
												</td>
												
												<td><label>Approve </label> <input type="checkbox" value="<?php echo $user_id;?>" name="users[]"  > </td>
												
																	 
												
												
											</tr>
										
											<?php
											}
											
											?>
											
										  </tbody>
									  </table>            
								<center>	<button type="submit" class="btn btn-info godown">Approve  </button></center>
				
				</form>

				


<?php include('../include/admin_footer.php');?>