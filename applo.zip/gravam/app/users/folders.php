<?php include('../include/header_user.php');?>




<div class="col-sm-10 col-sm-offset-3 col-md-10 col-md-offset-2 main">
     <ol class="breadcrumb ">
                  <li><a href="index.php">Dashboard</a></li>
                  <li class="active">Folder list</li>
      </ol>
        
						

		
 
	    <h3 class="page-header">Folder</h3>
		
		
				  <div class="row">
				<div class="col-md-7">
				<div class="Cbox">	
				
				
				
<table cellpadding="0" cellspacing="0" border="0" class="table table-striped table-bordered bootstrap-datatable datatable dataTable" id="example">
										  <thead>
											  <tr>
												  <th>Folder name</th>
												  <th>Date created</th>
												    <th>Action</th>
												  
											  </tr>
										  </thead>   
										  <tbody>
										  
												<?php	 
											
												$db_users=$dbtask->getFolders();
												while($row=$db_users->fetch(PDO::FETCH_ASSOC))
												{
													$folder_id=$row['folder_id'];
													$folder_name=$row['folder_name'];
													$date=$row['date'];


																				


												?>							  
											<tr>

												<td><?php echo $folder_name;?></td>
												<td><?php echo $date;?></td>
												<td><a href="docf.php?folder=<?php echo $folder_id;?>" target="blank"> view documents</a></td>
												
											</tr>
										
											<?php
											}
											
											?>
											
										  </tbody>
									  </table>  
						</div>
				</div>

				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
			
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				<div class="col-md-5">
					<div class="Cbox">
								<div class="row">
								<form  id="newfolder" class="fms" action="" method="post">
								<center><h3>New folder</h3></center>
									<div class="col-md-10">
									
													<div class="form-group">
														<label class="mylabel">Folder name </label>
														<input type="text" name="folder_name"class="form-control" placeholder="folder name">
													</div>
											  

													
												
																										<div class="info"></div>
													<center>	<button type="submit" class="btn btn-info">Add</button></center>
									
									</div>
					
										
											
											
							</form>
								</div>	
							
					</div>
				</div>
						
								
					
		  </div>
	
						
	
				
</div>
       

<?php include('../include/admin_footer.php');?>