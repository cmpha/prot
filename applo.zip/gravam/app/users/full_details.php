<?php include('../include/header_user.php');?>
<?php
$event_id=$_GET['event_id'];

?>


<div class="col-sm-10 col-sm-offset-3 col-md-10 col-md-offset-2 main">
     <ol class="breadcrumb ">
                  <li><a href="yr_events.php">Yearly events</a></li>
                  <li class="active">event details</li>
      </ol>
        
        
						
				
			          <h3 class="page-header">Event details</h3>
					  
	
										  
 
	<div class="row">
				<div class="col-sm-6">
			
							<div class="panel panel-default">
									 

									  <ul class="list-group">
												<?php	 
												
												$db_users=$dbtask->getEventByIdAll($event_id);
												while($row=$db_users->fetch(PDO::FETCH_ASSOC))
												{
													$year=$row['date'];
													$first_name=$row['first_name'];
													$last_name=$row['last_name'];
													$event_type=$row['type_name'];
													$event_id=$row['event_id'];
													$name=$row['name'];
													$total=$row['score'];
													$abbre=$row['abbre'];
													$discription=$row['description'];
												
												?>										  
													 									  
									  
									   <div class="panel-heading black"><strong>Project name:</strong><?php echo $name;?></div>
										<li class="list-group-item"><strong>Project type:</strong><?php echo $event_type;?></li>
										<li class="list-group-item"><strong>Score:</strong><?php echo $total;?> (<?php echo $abbre;?>)</li>
										<li class="list-group-item"><strong>Owner:</strong><?php echo "$first_name last_name";?></li>
									 
									  <div class="panel-body">
										<p><?php echo $discription;?></p>
									  </div>
									  <?php } ?>
									   </ul>
									</div>		
			</div>
				
	</div>	
				


<?php include('../include/admin_footer.php');?>