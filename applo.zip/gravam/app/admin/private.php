<?php include('../include/header.php');?>




<div class="col-sm-10 col-sm-offset-3 col-md-10 col-md-offset-2 main">
     <ol class="breadcrumb ">
                  <li><a href="index.php">Dashboard</a></li>
                  <li class="active">Private documents</li>
      </ol>
        
        
						
				
			          <h3 class="page-header">Private documents</h3>
			 <a class="btn btn-success pull-right" title="Click To add" href="new_document.php " >New document<i class="fa fa-plus"></i></a>		  
	<table cellpadding="0" cellspacing="0" border="0" class="table table-striped table-bordered bootstrap-datatable datatable dataTable" id="example">
										  <thead>
											  <tr>
												  <th>Document name</th>
												  <th>Type</th>
												  <th>Folder name</th>
												    <th>Authour</th>
												  <th>Date created</th>
												  <th>Action</th>
											  </tr>
										  </thead>   
										  <tbody>
										  
												<?php	 
												$visibilityexception="open";
												$db_users=$dbtask->getmyDocs($visibilityexception,$user_id);
												while($row=$db_users->fetch(PDO::FETCH_ASSOC))
												{
													$document_id=$row['document_id'];
													$document_name=$row['document_name'];
													$folder_name=$row['folder_name'];
													$type=$row['type'];
													$date=$row['date'];
													$username=$row['username'];
													$location=$row['location'];
												?>										  
											<tr>

												<td><?php echo $document_name;?></td>
												<td><?php echo $type;?></td>
												<td><?php echo $folder_name;?></td>
												<td><?php echo $username;?></td>
												<td><?php echo $date;?></td>
												
												
												
												<td>
			
													<a class="btnTable  btn-successTable " href="../controller/<?php echo $location;?>" target="blank">
														<i class="fa fa-eye">View</i>
														
													</a> || <a class="btnTable  btn-successTable " href="share.php?id=<?php echo $document_id;?>">
														<i class="fa fa-eye">Share</i> 
												
												</td>						
											</tr>
										<?php  } ?>
											
											<!--<tr>
                                             <th colspan="3" ><strong>Total Score :</strong><p class='pull-right'><?php echo @$sc;?></p></th>
											 </tr>
											 </tr>-->
										  </tbody>
									  </table>  				  
	<div class="row">
	
				
	</div>	
				


<?php include('../include/admin_footer.php');?>