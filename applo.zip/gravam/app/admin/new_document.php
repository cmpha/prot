<?php include('../include/header.php');?>




<div class="col-sm-10 col-sm-offset-3 col-md-10 col-md-offset-2 main">
     <ol class="breadcrumb ">
                  <li><a href="index.php">Dashboard</a></li>
                  <li class="active">New doc</li>
      </ol>
        
        
						
				
			          <h4 class="page-header">New document</h4>
					  <div class="row">
				<div class="col-md-2">
				</div>

				<div class="col-md-8">
					<div class="Cbox">
								<div class="row">
								<form  id="newDoc" class="fms" action="" method="post">
								<center><h4>Document details</h4></center>
									<div class="col-md-6">
									
									
													
													<div class="form-group">
														<label class="mylabel">File</label>
														<input type="file" name="file"class="form-control" >
													</div>
													
											<div class="control-group">
											<label class="mylabel">Document type</label>
											  <div class="controls">
												<select class="form-control" name="type">												
												<option value="">Choose</option>
												<option value="word_document">Word_document</option>
												<option value="pdf_document">pdf_document</option>
												
												</select>
											  </div>
											</div>											  

												
													
									
									</div>
					
										
									<div class="col-md-6">
											

											<div class="control-group">
											  <label class="mylabel">Folder</label>
											  <div class="controls">
												<select class="form-control" name="folder">
												
												<option value="">Choose</option>
												<?php
												$db_users=$dbtask->getFolders();
												while($row=$db_users->fetch(PDO::FETCH_ASSOC))
												{
													$folder_id=$row['folder_id'];
													$folder_name=$row['folder_name'];
													$date=$row['date'];
													?>
											<option value="<?php echo "$folder_id,$folder_name";?>"><?php echo $folder_name;?></option>
												<?php  } ?>
												</select>
											  </div>
											</div>
											  
											<div class="control-group">
											 <label class="mylabel">Visibility</label>
											  <div class="controls">
												<select class="form-control" name="visibility">												
												<option value="">Choose</option>
												<option value="open">Open</option>
												<option value="private">private</option>
												
												</select>
											  </div>
											</div>										
											<div class="control-group">
											 <label class="mylabel">Status</label>
											  <div class="controls">
												<select class="form-control" name="status">												
												<option value="">Choose</option>
												<option value="none">None</option>
												<option value="incomplete">Incomplete</option>
												<option value="completed">Completed</option>
												</select>
											  </div>
											</div>		
												<input type="hidden" name="user_id" value="<?php echo $user_id;?>">
													<br/>	<br/>	<br/>
													
													
											
											<div class="info"></div>
									</div>	
									
										<center>	<button type="submit" class="btn btn-info">New doc</button></center>	
											
							</form>
								</div>	
							
					</div>
				</div>
						
				<div class="col-md-2">
				</div>					
					
		  </div>				  
	<div class="row">
	
				
	</div>	
				


<?php include('../include/admin_footer.php');?>