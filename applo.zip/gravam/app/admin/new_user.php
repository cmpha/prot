<?php include('../include/header.php');?>




<div class="col-sm-10 col-sm-offset-3 col-md-10 col-md-offset-2 main">
     <ol class="breadcrumb ">
                  <li><a href="manage_users.php">Manage users</a></li>
                  <li class="active">New user</li>
      </ol>
        
						

		
 
	    <h3 class="page-header">New user</h3>
		
		
				  <div class="row">

				
				<div class="col-md-8">
					<div class="Cbox">
								<div class="row">
								<form  id="signupadmin" class="fms" action="" method="post">
								<center><h3>User Information</h3></center>
																		<div class="col-md-6">
									
													<div class="form-group">
														<label class="mylabel">First name</label>
														<input type="text" name="first_name"class="form-control" placeholder="first name">
													</div>
											  
													<div class="form-group">
													<label class="mylabel">Last name </label>
														<input type="text" name="last_name" class="form-control" placeholder="last name">
													</div>
													
													<div class="form-group">
														<label class="mylabel">username </label>
														<input type="text" name="username" class="form-control" placeholder="Username">
													</div>
													
									
									</div>
					
										
									<div class="col-md-6">
											
						
													<div class="form-group">
														<label class="mylabel">Email </label>
														<input type="text" name="email"class="form-control" placeholder="email">
													</div>
											  
													<div class="form-group">
														<label class="mylabel">Password </label>
														<input type="password" name="password" class="form-control" placeholder="password">
													</div>
													<div class="info"></div>
													<center>	<button type="submit" class="btn btn-info">Add</button></center>
													
											
											
									</div>		

											
											
							</form>
								</div>		
							
					</div>
				</div>
						
								
					
		  </div>
	
						
	
				
</div>
       

<?php include('../include/admin_footer.php');?>