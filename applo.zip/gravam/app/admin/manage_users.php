<?php include('../include/header.php');?>




<div class="col-sm-10 col-sm-offset-3 col-md-10 col-md-offset-2 main">
     <ol class="breadcrumb ">
                  <li><a href="index.php">Dashboard</a></li>
                  <li class="active">manage users</li>
      </ol>
        
						
				
			          <h4 class="page-header">Manage users</h4>

				

	
		
 <a class="btn btn-success pull-right" title="Click To add" href="new_user.php " >New user <i class="fa fa-plus"></i></a>
										<table cellpadding="0" cellspacing="0" border="0" class="table table-striped table-bordered bootstrap-datatable datatable dataTable" id="example">
										  <thead>
											  <tr>
												  <th>First Name</th>
												  <th>Last Name</th>
												  <th>Username</th>
												  <th>Email</th>
												
												  <th>Date registered</th>
											
												  <th>Status</th>
												
												  <th>Actions</th>
											  </tr>
										  </thead>   
										  <tbody>
										  
												<?php	 
												$sts="pending";
												$db_users=$dbtask->getUsers();
												while($row=$db_users->fetch(PDO::FETCH_ASSOC))
												{
													$user_id=$row['user_id'];
													$first_name=$row['first_name'];
													$last_name=$row['last_name'];
													$username=$row['username'];
													$password=$row['password'];
													$role=$row['role'];
													$date=$row['date'];
													$email=$row['email'];
													$status=$row['status'];
																		
													//$ago=$dbtask->time_ago($date);

												?>										  
											<tr>

												<td><?php echo $first_name;?></td>
												<td><?php echo $last_name;?></td>
												<td><?php echo $username;?></td>
												<td><?php echo $email;?></td>
												
												<td class="center"><?php echo $date;?></td>
												<td class="center">
													<?php 
													if($status=='approved'){
													?>
													<span class="badge badge-success"><?php echo $status;	?></span>
													
													<?php
} 
													else{
													?>
														<span class="badge badge-important"> <?php echo $status;?></span>
													<?php
													}
													?>
												</td>
												
															 
												
												<td class="center">
												<?php 
													if($status=='approved'){
													
													}else{
													?>
													<a class="btnTable  btn-successTable " href="update_user.php?id=<?php echo $user_id;?>">
														<i class="fa fa-pencil"> Update</i> 
													</a>
													<?php } ?>
													
												</td>
											</tr>
										
											<?php
											}
											
											?>
											
										  </tbody>
									  </table> 


		
				  <div class="row">
				
				
				
				
				
				
				
						
								
					
		  </div>
	
						
	
				
</div>
       

<?php include('../include/admin_footer.php');?>