<?php include('../include/header.php');?>




<div class="col-sm-10 col-sm-offset-3 col-md-10 col-md-offset-2 main">
     <ol class="breadcrumb ">
                  <li><a href="index.php">Dashboard</a></li>
                  <li class="active">Reports</li>
      </ol>
        
						
				
			          <h3 class="page-header">Admin Dashboard</h3>
			<div class="row">
			
			
			
<div class="col-md-3">

					<div class="span3 statbox purple" ontablet="span6" ondesktop="span3">
					<div class="boxchart"><canvas width="64" height="60" style="display: inline-block;width: 64px; background-image: url('../media/images/em.png');height: 60px;vertical-align: top;"><img src="images/em.png"></canvas></div>
																	
								<?php
								$table="users";
								$column="user_id";
								$db_users=$dbtask-> Counttable($table,$column);
								while($row=$db_users->fetch(PDO::FETCH_ASSOC))
								{
								
									$total=$row['total'];

										?>
												
													<div class="number"><?php echo $total;?><i class="fa fa-group"></i></div>
													<?php } ?>
				
					<div class="title">System Users</div>
					<div class="footer">
					<a href=""> read full report</a>
					</div>	
				</div>

			</div>	



			
			<div class="col-md-3">

					<div class="span3 statbox yellow" ontablet="span6" ondesktop="span3">
					<div class="boxchart"><canvas width="64" height="60" style="display: inline-block;width: 64px; background-image: url('../media/images/em.png');height: 60px;vertical-align: top;"><img src="images/em.png"></canvas></div>

								<?php
								$table="folders";
								$column="folder_id";
								$db_users=$dbtask-> Counttable($table,$column);
								while($row=$db_users->fetch(PDO::FETCH_ASSOC))
								{
								
									$total=$row['total'];

										?>
																								
													<div class="number"><?php echo $total;?><i class="fa fa-folder-close"></i></div>
													<?php } ?>
					
					<div class="title">Folders</div>
					
					<div class="footer">
					<a href=""> read full report</a>
					</div>					
				</div>

			</div>
			
			
			
				<div class="col-md-3">

					<div class="span3 statbox green" ontablet="span6" ondesktop="span3">
					<div class="boxchart"><canvas width="64" height="60" style="display: inline-block;width: 64px; background-image: url('../media/images/em.png');height: 60px;vertical-align: top;"><img src="images/em.png"></canvas></div>

																																																			

											<?php
								$table="documents";
								$column="document_id";
								$db_users=$dbtask-> Counttable($table,$column);
								while($row=$db_users->fetch(PDO::FETCH_ASSOC))
								{
								
									$total=$row['total'];

										?>
																								
													<div class="number"><?php echo $total;?> <i class="fa fa-file"></i></div>
													<?php } ?>
				
					<div class="title">Documents </div>
					<div class="footer">
					<a href=""> read full report</a>
					</div>	
			</div>
		</div>
			
		




		<div class="row">
		<div class="col-md-12">
		<div class="widget blue span5 demog" ontablet="span6" ondesktop="span5">
					
					<h4><span class="glyphicons globe"><i></i></span>Folder Demographics</h4>
					
					<hr>
					
					<div class="content">
						
						<div class="verticalChart">
							<?php

								$db_users=$dbtask-> getOrgDemographics();
								while($row=$db_users->fetch(PDO::FETCH_ASSOC))
								{
									$folder_name=$row['folder_name'];
									$total=$row['total'];

										?>
							
							<div class="singleBar">
							
								<div class="bar">
								
									<div class="value" style="height: <?php echo $total ; ?>%;">
										<span style="color: rgb(45, 137, 239); display: inline;"><?php echo $total ; ?></span>
									</div>
								
								</div>
								
								<div class="title"><?php echo $folder_name ;?></div>
							
							</div>
													<?php }?>
							

							<div class="clearfix"></div>
							
						</div>
					
					</div>
					
				</div>
		
		
		</div>
</div>  

<?php include('../include/admin_footer.php');?>