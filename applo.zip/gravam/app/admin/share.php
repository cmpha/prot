<?php include('../include/header.php');?>




<div class="col-sm-10 col-sm-offset-3 col-md-10 col-md-offset-2 main">
     <ol class="breadcrumb ">
                  <li><a href="index.php">Dashboard</a></li>
                  <li class="active">Share</li>
      </ol>
        
        
						
				
			 <h4 class="page-header">Share			<div class="choices">	<input name="button" class="btn btn-success" type="button" id="buttonadd" value="Add user"/>
			<input name="button" class="btn btn-danger" type="button" id="buttonremove" value="Remove user"/></div>
		  </h4>
					  		

					<div class="Cbox">
								<div class="row">
							
								<form  id="newshare" class="fms" action="" method="post">
								
								
									<div class="col-md-12">
					<?php	 

						$id=$_GET['id'];
						$getUserData=$dbtask->getdocByID($id);
						while($row=$getUserData->fetch(PDO::FETCH_ASSOC))
								{
									$document_id=$row['document_id'];
									$document_name=$row['document_name'];
									$folder_name=$row['folder_name'];
									$type=$row['type'];
									$date=$row['date'];
									$username=$row['username'];
									$location=$row['location'];
						
						?>	

													
																   <div id="buttondiv">

																	</div>
																		<?php }?>
									</div>
					
										
									<div class="col-md-3">
											

													
													
											<center>	<button type="submit" class="btn btn-info">Share</button></center>			
											
											<div class="info"></div>
									</div>	
									
										
											
							</form>
						
								</div>	
							
					</div>
</div>
	


<?php include('../include/admin_footer.php');?>