<?php

include ('../class/main_class.php');


$dbtask = new SYSTEM_CLASS();
@$total = count($_POST["users"]);
if($total <1){

echo "<div class='alert alert-danger'>Please choose user</div>";

}

else{
$people= $_POST["users"];
$status= "approved";


	foreach($people as $doc)
		{
			$user_id = $doc;
			$assign= $dbtask->approve($user_id,$status);
		}
		
		if($assign){
				 echo "<div class='alert alert-success'>
                    <strong>$total users(s) approved</strong>
			.
                </div>";
		}
		else{
			echo"failed".mysql_error();
		}
		

	}
		
				
?>
