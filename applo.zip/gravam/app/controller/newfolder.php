<?php

include ('../class/main_class.php');


$dbtask = new SYSTEM_CLASS();

						
		/* add admin script*/
		$folder_name = $_POST['folder_name'];
		$date =date('Y-m-d');
		$dir="documents"."/$folder_name";

		 
		if(empty($folder_name))
		{
		echo"<div class='alert alert-danger'> <p>please enter folder name</p> </div>";
		}
		
		 elseif( is_dir($dir)) {
		 
			echo"<div class='alert alert-danger'> <p>folder name exist, choose new one</p> </div>";
		 }

		else
		  {
			$exec=mkdir( $dir,true); 
			
					$send = $dbtask->create_folder($folder_name,$date);

					if($send && $exec )
						{
						
						echo "<div class='alert alert-success'> <p><i class='icon-check'></i> folder $folder_name  created </p> </div>";
						
						}
						else
						
							{
							echo "<div class='alert alert-danger'> <p><i class='icon-remove'></i> Failed </p> </div>";
							}
			}



	
		
				
?>
