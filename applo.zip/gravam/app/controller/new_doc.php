<?php

include ('../class/main_class.php');


$dbtask = new SYSTEM_CLASS();

						
						
if(is_array($_FILES)) {

					$folder=$_POST['folder'];
					$inputstring7=$folder;
					$string_convert= explode(",",$inputstring7);
					$folder_id=$string_convert[0];
					$folder_name=$string_convert[1];
					
		
		$type = $_POST['type'];
		$date = date('d-m-y');
		$visibility = $_POST['visibility'];
		$status = $_POST['status'];
		$user_id = $_POST['user_id'];
		

				
		if(empty($type))
				{
					echo"<div class='alert-danger'>choose document type</di>";
				}	

		elseif(empty($visibility))
				{
					echo"<div class='alert-danger'>choose document visibility</di>";
				}	

		elseif(empty($status))
				{
					echo"<div class='alert-danger'>Please choose status</di>";
				}

		else{				

  
if(is_uploaded_file($_FILES['file']['tmp_name']))
				{
					$sourcePath = $_FILES['file']['tmp_name'];
					$location = "documents/$folder_name/".$_FILES['file']['name'];
					$document_name = $_FILES['file']['name'];
					
					$db_users=$dbtask->GetthisFile($document_name);
					$row=$db_users->fetch(PDO::FETCH_ASSOC);
					$count=$row['total'];
					
					if($count >0){
					echo"<div class='alert-danger'>Document exist already</di>";
					
				   }
				   else{
				
							
						if(move_uploaded_file($sourcePath,$location)) 
								{
								
                                $insert=$dbtask->new_document($document_name,$location,$type,$folder_id,$date,$visibility,$status,$user_id);
								
								
										

										if($insert)
												{

																echo"<div class='alert-success'>document added to $folder_name </div>";
												}								
											else
													{
														echo"<div class='alert-danger'>Failed</div>";
													}
								}
				
			
				else{
				
					echo"<div class='alert-danger'>Failed to upload</div>";
				
				}
			
			}
			}
			}
}
	
		
				
?>
