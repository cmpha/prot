<?php

include ('../class/main_class.php');


$dbtask = new SYSTEM_CLASS();

						
						
		/* add admin script*/
		$first_name = $_POST['first_name'];
		$last_name = $_POST['last_name'];
		$username = $_POST['username'];
		$pass= sha1($_POST['password']);
		$email = $_POST['email'];
		$role = "user";
		$date = date('Y-m-d H:i:s');
		$status="pending";


		$password= $pass;
		if(empty($first_name))
		{
		echo"<div class='alert alert-danger'> <p>please enter first name</p> </div>";
		}
		
			elseif(empty($last_name))
				{
				echo "<div class='alert alert-danger'> <p><i class='icon-remove'></i> Please enter surname</p> </div>";
				}
			
			elseif(empty($username))
				{
				echo " <div class='alert alert-danger'> <p><i class='icon-remove'></i> Please enter user name</p></div>";
				}
			
			elseif(empty($password))
				{
				echo "<div class='alert alert-danger'> <p><i class='icon-remove'></i> Please enter password</p> </div>";
				}
			
			elseif(empty($role))
				{
				echo "<div class='alert alert-danger'> <p><i class='icon-remove'></i> Please enter post</p> </div>";
				}
			

			
			
		else
		  {

					$send = $dbtask->create_user($first_name,$last_name,$username,$password,$email,$role,$date,$status);

					if($send)
						{
						
						echo "<div class='alert alert-success'> <p><i class='icon-check'></i> Registered</p> </div>";
						
						
						
						}
						else
						
							{
							echo "<div class='alert alert-danger'> <p><i class='icon-remove'></i> Failed adding user </p> </div>";
							}
			}



	
		
				
?>
