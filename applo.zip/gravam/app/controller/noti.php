<?php



session_start();
if (!isset($_SESSION["user_id"])) {
    header("location:../index.php");
    exit();
}
$user_id=$_SESSION["user_id"];
$username=$_SESSION['username'];
$role=$_SESSION['role'] ;

include ('../class/main_class.php');


$dbtask = new SYSTEM_CLASS();

						
				
						$view="unread";
												$db_users=$dbtask->getnoti($view,$user_id);
												$row1=$db_users->fetch(PDO::FETCH_ASSOC);
											
												
												
													$total=$row1['total'];		
				
?>
  <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown"><span class="badge badge-danger"><?php echo $total;?> </span> notifications<b class="caret"></b></a>
                    <ul class="dropdown-menu">
					<?php
						$view="unread";
												$db_users=$dbtask->getnoti($view,$user_id);
												while($row=$db_users->fetch(PDO::FETCH_ASSOC))
												{
													$document_id=$row['document_id'];
													$document_name=$row['document_name'];
													$total=$row['total'];
													$date=$row['date'];
													$ago=$dbtask->time_ago($date);
													
													?>
                      <li><a href="viewD.php?doc=<?php echo $document_id;?>"><?php echo "$document_name shared $ago";?></a></li>
                    <?php } ?>
                    </ul>
                  </li>	
	