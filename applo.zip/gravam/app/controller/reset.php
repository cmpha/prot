<?php
include('../class/main_class.php');
 $try= new SYSTEM_CLASS();
		$id = $_POST['doctor_id'];
		$first_name = $_POST['first_name'];
		$last_name = $_POST['last_name'];
		$username = $_POST['username'];
		$pass = $_POST['password'];
		$email = $_POST['email'];
		$code = $_POST['code'];
		
	if(empty($first_name))
		{
		echo"<div class='alert alert-danger'> <p>please enter first name</p> </div>";
		}
		
			elseif(empty($last_name))
				{
				echo "<div class='alert alert-danger'> <p><i class='icon-remove'></i> Please enter surname</p> </div>";
				}
			
			elseif(empty($username))
				{
				echo " <div class='alert alert-danger'> <p><i class='icon-remove'></i> Please enter user name</p></div>";
				}
			
			elseif(empty($pass))
				{
				echo "<div class='alert alert-danger'> <p><i class='icon-remove'></i> Please enter password</p> </div>";
				}

			elseif(empty($id))
				{
				echo "<div class='alert alert-danger'> <p><i class='icon-remove'></i> error</p> </div>";
				}
			

			
			
		else
		  {
               $password = sha1($pass);
			   $status="confirmed";
					$send = $try->update_recovery($first_name,$last_name,$email,$username,$password,$id);
					$send2 = $try->update_code($code,$status);

					if($send && $send2)
						{
					
						echo "<div class='alert alert-success'> <p><i class='icon-check'></i> Updated</p> </div>";
						
					
						
						}
						else
						
							{
							echo "<div class='alert alert-danger'> <p><i class='icon-remove'></i> Failed  </p> </div>";
							}
			}			









?>