<?php
include('../class/security_class.php');

//login
 $security= new SECURITY();
		$username=$_POST['username'];
		$password=sha1($_POST['password']);


		
		if(empty($username)){
		echo"<div class='alert alert-danger'>please enter your username</div>";
		}
		
		elseif(empty($password)){
		echo"<div class='alert alert-danger'> please enter password</div>";
		}
		else{
			   try {
					 $auth =$security->login($username,$password);
				   }
			   catch(PDOException $e)
				  {
				echo"<div class='alert alert-danger'>Something messed up!</div>"; 
					write_error_to_log($e->getMessage());
				  } 
					
			}			







?>