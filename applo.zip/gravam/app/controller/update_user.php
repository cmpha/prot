<?php
include('../class/main_class.php');
 $try= new SYSTEM_CLASS();
		$user_id = $_POST['user_id'];	
			$status=$_POST['status'];
		$role=$_POST['role'];
		
			if(empty($user_id))
				{
				echo "<div class='alert alert-danger'> <p><i class='icon-remove'></i> error</p> </div>";
				}
			

			
			
		else
		  {
               
					$send = $try->update_us($status,$user_id,$role);

					if($send)
						{
					
						echo "<div class='alert alert-success'> <p><i class='icon-check'></i> Updated</p> </div>";
						
					
						
						}
						else
						
							{
							echo "<div class='alert alert-danger'> <p><i class='icon-remove'></i> Failed  </p> </div>";
							}
			}			







?>