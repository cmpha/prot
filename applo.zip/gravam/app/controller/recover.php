<?php

include ('../class/main_class.php');


$dbtask = new SYSTEM_CLASS();

						
	
		$email = $_POST['email'];
		$date = date('Y-m-d H:i:s');
		$status="valid";
		$code = md5(date('Y-m-d H:i:s'));
		if(empty($email))
		{
		echo"<div class='alert alert-danger'> <p>please enter email</p> </div>";
		}
		
		
		else
		  {

					$get = $dbtask->checkMail($email);
					$row=$get->fetch(PDO::FETCH_ASSOC);
					$count= $row['total'];
					$id= $row['doctor_id'];
					if($count<1){
						echo "<div class='alert alert-danger'> <p><i class='icon-remove'></i>Email doesnt exist </p> </div>";
					}
					else{
					$try=$dbtask->recover($code,$date,$status,$id) ;
					if($try){
					
																require 'PHPMailer/PHPMailerAutoload.php';

																$mail = new PHPMailer;

																$mail->isSMTP();                            // Set mailer to use SMTP
																$mail->Host = 'smtp.gmail.com';             // Specify main and backup SMTP servers
																$mail->SMTPAuth = true;                     // Enable SMTP authentication
																$mail->Username = 'donmap2@gmail.com';  // SMTP username
																$mail->Password = 'mulanje123'; // SMTP password
																$mail->SMTPSecure = 'tls';                  // Enable TLS encryption, `ssl` also accepted
																$mail->Port = 587;                          // TCP port to connect to

																$mail->setFrom('info@malawimedicalcouncil.com', 'Medical Council of Malawi');
																$mail->addReplyTo('Noreply', 'Medical Council of Malawi');
																$mail->addAddress($email);   // Add a recipient
																$mail->isHTML(true);  // Set email format to HTML
																$mail->Subject = 'Medical Council of Malawi password recovery';
																$bodyContent = '<h1> Acount recovery</h1>';
																$stm1='<p>';
														       $stm2='<a href="http://localhost/nail/app/reset.php?id=';
															    $stm3=$code;
																 $stm4='"> follow this link to recover your account</a></p><br/>';
																$link=$stm1.$stm2.$stm3.$stm4;
																$bodyContent='<p>$link </p>';
																$bodyContent ='<p></p>'.$link;

																
																$mail->Body    = $bodyContent;

																if(!$mail->send()) {
																	echo "<div class='alert alert-danger'> <p><i class='icon-remove'></i>failed to send email </p> </div>";
																	
																	echo 'Mailer Error: ' . $mail->ErrorInfo;
																} 
																else {
																echo "<div class='alert alert-success'> <p><i class='icon-remove'></i>email sent!</p> </div>";
																}					
					
					
					}
					else{
					echo "<div class='alert alert-danger'> <p><i class='icon-remove'></i>failed </p> </div>";
					}
           
			
				}
			}   



	
		
				
?>
