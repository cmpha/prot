<?php

include ('../class/main_class.php');


$dbtask = new SYSTEM_CLASS();

						
						
		/* add admin script*/
		$us_name = $_POST['us_name'];
		
	
	
		if(empty($us_name))
		{
		echo"<div class='alert alert-danger'> <p>please enter group name</p> </div>";
		}
		
			
		else
		  {

					$send = $dbtask->create_group($us_name) ;

					if($send)
						{
						
						echo "<div class='alert alert-success'> <p><i class='icon-check'></i> $us_name added</p> </div>";
						
						
						
						}
						else
						
							{
							echo "<div class='alert alert-danger'> <p><i class='icon-remove'></i> Failed </p> </div>";
							}
			}



	
		
				
?>
