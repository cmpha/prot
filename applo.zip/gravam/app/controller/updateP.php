<?php
include('../class/main_class.php');
 $try= new SYSTEM_CLASS();
		$user_id = $_POST['user_id'];
		$first_name = $_POST['first_name'];
		$last_name = $_POST['last_name'];
		$username = $_POST['username'];
		$pass = $_POST['password'];
		$email = $_POST['email'];
		$role = $_POST['role'];
		$date = date('Y-m-d');
		$status=$_POST['status'];
	
		
		if(empty($first_name))
		{
		echo"<div class='alert alert-danger'> <p>please enter first name</p> </div>";
		}
		
			elseif(empty($last_name))
				{
				echo "<div class='alert alert-danger'> <p><i class='icon-remove'></i> Please enter surname</p> </div>";
				}
			
			elseif(empty($username))
				{
				echo " <div class='alert alert-danger'> <p><i class='icon-remove'></i> Please enter user name</p></div>";
				}
			
			elseif(empty($pass))
				{
				echo "<div class='alert alert-danger'> <p><i class='icon-remove'></i> Please enter password</p> </div>";
				}
			
			elseif(empty($role))
				{
				echo "<div class='alert alert-danger'> <p><i class='icon-remove'></i> Please enter post</p> </div>";
				}
			elseif(empty($user_id))
				{
				echo "<div class='alert alert-danger'> <p><i class='icon-remove'></i> error</p> </div>";
				}
			

			
			
		else
		  {
               $password = sha1($pass);
					$send = $try->update_user($first_name,$last_name,$username,$password,$email,$role,$date,$status,$user_id);

					if($send)
						{
					
						echo "<div class='alert alert-success'> <p><i class='icon-check'></i> Updated</p> </div>";
						
					
						
						}
						else
						
							{
							echo "<div class='alert alert-danger'> <p><i class='icon-remove'></i> Failed  </p> </div>";
							}
			}			







?>