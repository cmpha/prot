<?php

include ('../class/main_class.php');


$dbtask = new SYSTEM_CLASS();
			$u="john";
			$user=sha1($u);
echo"$user";			
						
		/* add admin script*/
		$users = $_POST['users'];
		$document_id = $_POST['document_id'];
		$notes = $_POST['notes'];
		$status = $_POST['status'];
		$date = date('Y-m-d H:i:s');
		$owner= $_POST['owner'];
		$count= count( $_POST['users']);
	     if($count <0){
		 
		 echo"<div class='alert alert-danger'> <p>pleasechoose altleast one user</p> </div>";
		 
		 }
	
		elseif(empty($document_id))
		{
		echo"<div class='alert alert-danger'> <p>no document was selected</p> </div>";
		}
		
			elseif(empty($notes))
				{
				echo "<div class='alert alert-danger'> <p><i class='icon-remove'></i> Please notes</p> </div>";
				}
			
			elseif(empty($status))
				{
				echo "<div class='alert alert-danger'> <p><i class='icon-remove'></i> Please set status</p> </div>";
				}
			
		else
		  {
		  
		  foreach($users as $user_id){
               $view="unread";
				$send = $dbtask->share($document_id,$user_id,$notes,$status,$view,$date,$owner);
					
					}

					if($send)
						{
						
						echo "<br/><br/> <div class='alert alert-success'> <p><i class='icon-check'></i> document shared to $count user(s)</p> </div>";
						
						
						
						}
						else
						
							{
							echo "<div class='alert alert-danger'> <p><i class='icon-remove'></i> Failed to share</p> </div>";
							}
			}



	
		
				
?>
