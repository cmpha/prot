<?php
include ('../class/setUp_class.php');
include ('../class/main_class.php');

$dbtask = new SET_UP();
$dbtask1 = new SYSTEM_CLASS();
/*drop DB*/

$create1 =$dbtask->create_table1();
$create2 =$dbtask->create_table2();
$create3 =$dbtask->create_table3();
$create4 =$dbtask->create_table4();
if($create1 && $create2 && $create3 && $create4){


					
		$first_name = $_POST['first_name'];
		$last_name = $_POST['last_name'];
		$username = $_POST['username'];
		$password = sha1($_POST['password']);
		$email = $_POST['email'];
		$role = "admin";
		$date = date('y-m-d');
		$status="approved";

		
		if(empty($first_name))
		{
		echo"<div class='alert alert-danger'> <p>please enter first name</p> </div>";
		}
		
			elseif(empty($last_name))
				{
				echo "<div class='alert alert-danger'> <p><i class='icon-remove'></i> Please enter surname</p> </div>";
				}
			
			elseif(empty($username))
				{
				echo " <div class='alert alert-danger'> <p><i class='icon-remove'></i> Please enter user name</p></div>";
				}
			
			elseif(empty($password))
				{
				echo "<div class='alert alert-danger'> <p><i class='icon-remove'></i> Please enter password</p> </div>";
				}
			
			elseif(empty($role))
				{
				echo "<div class='alert alert-danger'> <p><i class='icon-remove'></i> Please enter post</p> </div>";
				}
			

			
			
		else
		  {



					$send = $dbtask1->create_user($first_name,$last_name,$username,$password,$email,$role,$date,$status);

					if($send )
						{
						echo "<div class='alert alert-success'> <p><i class='icon-check'></i> Set up completed</p> </div>";
						echo "<div class='alert alert-success'> <p><i class='icon-check'></i> Admin added</p> </div>";
						
						echo"<a class='btn btn-success' href='app/index.php'> Continue</a>";
						
						}
						else
						
							{
							echo "<div class='alert alert-danger'> <p><i class='icon-remove'></i> Failed adding user $date </p> </div>";
							}
			}


}

else{


	echo "<div class='alert alert-danger'> <p><i class='icon-remove'></i> Failed to install </p> </div>";

}
	
		
				
?>
