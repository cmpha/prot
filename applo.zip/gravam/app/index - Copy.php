<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="">

    <title>Medical council of Malawi</title>
    <link href="media/css/bootstrap.min.css" rel="stylesheet">
    <link href="media/css/style.css" rel="stylesheet">
	<link rel="stylesheet" href="media/css/font-awesome.min.css" />

  </head>

  <body>

<!-- Header Starts -->
<div class="navbar-wrapper">

        <div class="navbar-inverse" role="navigation">
          <div class="container">
            <div class="navbar-header">
             <img class="logo" src="media/images/logo1.png">

              <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target=".navbar-collapse">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
              </button>

            </div>


            <!-- Nav Starts -->
            <div class="navbar-collapse  collapse">
              <ul class="nav navbar-nav navbar-right">
					<li class="active"><a href="index.php">Login</a></li>
					<li><a href="signup.php">Signup</a></li>
              </ul>
            </div>
            <!-- #Nav Ends -->

          </div>
        </div>

    </div>
	<!-- #Header ends-->
			<div class="banner">
			<div class="banner-info">
				<h2>Telecom and IT support provider for small business</h2>
				<p>Our services are fully managed and we</p>
				<p>view ourselves as IT department of our company</p>
				<a href="contact.html" class="btn btn-1 btn-1d">Request a quote</a>
			</div>
		</div>

    <div class="container">
		  <div class="row">
				<div class="col-md-3">
				</div>

				<div class="col-md-6">
					<div class="Cbox">
					
								<center><h3>Login</h3></center>
					
									<form  id="login" class="fm" action="" method="post">
				
											<div class="form-group">
												<label class="mylabel">Email <i class="fa fa-envelope"></i></label>
												<input type="text" name="email"class="form-control" placeholder="username">
											</div>
									  
											<div class="form-group">
												<label class="mylabel">Password  <i class="fa fa-lock"></i></label>
												<input type="password" name="password" class="form-control" placeholder="password">
											</div>
											<div class="info"></div>
											<center>	<button type="submit" class="btn btn-info">Login</button></center>
											
									</form>
									
									<center><p class="topspace"> Dont have an account? <a href="signup.php">Signup</a></p><center>
									  
					</div>
				</div>
						
				<div class="col-md-3">
				</div>					
					
		  </div>
    </div>

<footer>

		<p>
			© 2017 <a href="">medical council of Malawi</a>
			
		</p>

	</footer>
    <!-- Placed at the end of the document so the pages load faster -->
	<!-- start: JavaScript-->

	<script src="media/js/jquery.js"></script>
		<script src="media/js/bootstrap.min.js"></script>
		<!--table--->
		 <script src="media/js/jquery-1.7.2.min.js"></script>			
		 <script type="text/javascript" charset="utf-8" language="javascript" src="media/js/jquery.dataTables.js"></script>
		<script type="text/javascript" charset="utf-8" language="javascript" src="media/js/DT_bootstrap.js"></script>
		<script type="text/javascript">
$(document).ready(function (e) {
	$("#login").on('submit',(function(e) {
		e.preventDefault();
		$.ajax({
        	url: "controller/log.php",
			type: "POST",
			data:  new FormData(this),
			contentType: false,
    	    cache: false,
			processData:false,
				beforeSend: function() 
			{
				$(".info").html('<center><img class="gifi" src="media/images/loader.gif" alt="Loading...." align="absmiddle" title="Loading...."/></center>');
			},
			success: function(data)
		    {
			$(".info").fadeIn(5000).html(data);
	
		    },
		  	error: function() 
	    	{
	    	} 	        
	   });
	}));
});
</script>
	<!-- end: JavaScript-->

  </body>
</html>
