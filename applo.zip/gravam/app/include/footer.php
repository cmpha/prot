<section id="bottom" class="main">
    <!--Container-->
    <div class="container">

       
        <div class="row-fluid">

           
            <div class="col-md-3">
                <h4>medical Council of Malawi</h4>
                     <ul class="arrow">
                        <li><a href="">About Us</a></li>
                        <li><a href="#">Terms of Use</a></li>
                        <li><a href="#">Copyright</a></li>
                        <li><a href="#">News</a></li>

                    </ul>              
            </div>
          

           
            <div id="" class="col-md-3">
              
            </div>
       
            <div id="" class="col-md-3">
             
                <div>

                </div>
            </div>
        

            <div class="col-md-3">
            
            

        </div>

    </div>
   
</div>


</section>
<footer>

		<p>
		<div class="span5">
               <p> © 2017 <a target="_blank" href="" title="Medical council of Malawi">Medical council of Malawi</a>. All Rights Reserved.</p>
            </div>
			
		</p>

	</footer>

    <!-- Placed at the end of the document so the pages load faster -->
	<!-- start: JavaScript-->

	<script src="../media/js/jquery.js"></script>
		<script src="../media/js/bootstrap.min.js"></script>
		<!--table--->
		 <script src="../media/js/jquery-1.7.2.min.js"></script>			
		 <!--<script type="text/javascript" charset="utf-8" language="javascript" src="../media/js/jquery.dataTables.js"></script>
		<script type="text/javascript" charset="utf-8" language="javascript" src="../media/js/DT_bootstrap.js"></script>-->
	<!-- end: JavaScript-->
	</script>
	<script type="text/javascript">
$(document).ready(function (e) {
	$("#newfolder").on('submit',(function(e) {
		e.preventDefault();
		$.ajax({
        	url: "../controller/newfolder.php",
			type: "POST",
			data:  new FormData(this),
			contentType: false,
    	    cache: false,
			processData:false,
				beforeSend: function() 
			{
				$(".info").html('<center><img class="gifi" src="../media/images/loader.gif" alt="Loading...." align="absmiddle" title="Loading...."/></center>');
			},
			success: function(data)
		    {
			$(".info").fadeIn(5000).html(data);
	
		    },
		  	error: function() 
	    	{
	    	} 	        
	   });
	}));
});
</script>


	<script type="text/javascript">
$(document).ready(function (e) {
	$("#Upuser").on('submit',(function(e) {
		e.preventDefault();
		$.ajax({
        	url: "../controller/update_user.php",
			type: "POST",
			data:  new FormData(this),
			contentType: false,
    	    cache: false,
			processData:false,
				beforeSend: function() 
			{
				$(".info").html('<center><img class="gifi" src="../media/images/loader.gif" alt="Loading...." align="absmiddle" title="Loading...."/></center>');
			},
			success: function(data)
		    {
			$(".info").fadeIn(5000).html(data);
	
		    },
		  	error: function() 
	    	{
	    	} 	        
	   });
	}));
});
</script>	






	
	<script type="text/javascript">
$(document).ready(function (e) {
	$("#newGroup").on('submit',(function(e) {
		e.preventDefault();
		$.ajax({
        	url: "../controller/new_group.php",
			type: "POST",
			data:  new FormData(this),
			contentType: false,
    	    cache: false,
			processData:false,
				beforeSend: function() 
			{
				$(".info").html('<center><img class="gifi" src="../media/images/loader.gif" alt="Loading...." align="absmiddle" title="Loading...."/></center>');
			},
			success: function(data)
		    {
			$(".info").fadeIn(5000).html(data);
	
		    },
		  	error: function() 
	    	{
	    	} 	        
	   });
	}));
});
</script>	
	
	<script type="text/javascript">
$(document).ready(function (e) {
	$("#newOrg").on('submit',(function(e) {
		e.preventDefault();
		$.ajax({
        	url: "../controller/new_org.php",
			type: "POST",
			data:  new FormData(this),
			contentType: false,
    	    cache: false,
			processData:false,
				beforeSend: function() 
			{
				$(".info").html('<center><img class="gifi" src="../media/images/loader.gif" alt="Loading...." align="absmiddle" title="Loading...."/></center>');
			},
			success: function(data)
		    {
			$(".info").fadeIn(5000).html(data);
	
		    },
		  	error: function() 
	    	{
	    	} 	        
	   });
	}));
});
</script>


	<script type="text/javascript">
$(document).ready(function (e) {
	$("#approve").on('submit',(function(e) {
		e.preventDefault();
		$.ajax({
        	url: "../controller/choose.php",
			type: "POST",
			data:  new FormData(this),
			contentType: false,
    	    cache: false,
			processData:false,
				beforeSend: function() 
			{
				$(".info").html('<center><img class="gifi" src="../media/images/loader.gif" alt="Loading...." align="absmiddle" title="Loading...."/></center>');
			},
			success: function(data)
		    {
			$(".info").fadeIn(5000).html(data);
	
		    },
		  	error: function() 
	    	{
	    	} 	        
	   });
	}));
});
</script>
	<script type="text/javascript">
$(document).ready(function (e) {
	$("#newshare").on('submit',(function(e) {
		e.preventDefault();
		$.ajax({
        	url: "../controller/share.php",
			type: "POST",
			data:  new FormData(this),
			contentType: false,
    	    cache: false,
			processData:false,
				beforeSend: function() 
			{
				$(".info").html('<center><img class="gifi" src="../media/images/loader.gif" alt="Loading...." align="absmiddle" title="Loading...."/></center>');
			},
			success: function(data)
		    {
			$(".info").fadeIn(5000).html(data);
	
		    },
		  	error: function() 
	    	{
	    	} 	        
	   });
	}));
});
</script>

	<script type="text/javascript">
$(document).ready(function (e) {
	$("#newevent").on('submit',(function(e) {
		e.preventDefault();
		$.ajax({
        	url: "../controller/new_event.php",
			type: "POST",
			data:  new FormData(this),
			contentType: false,
    	    cache: false,
			processData:false,
				beforeSend: function() 
			{
				$(".info").html('<center><img class="gifi" src="../media/images/loader.gif" alt="Loading...." align="absmiddle" title="Loading...."/></center>');
			},
			success: function(data)
		    {
			$(".info").fadeIn(5000).html(data);
	
		    },
		  	error: function() 
	    	{
	    	} 	        
	   });
	}));
});
</script>
			<script type="text/javascript">
$(document).ready(function (e) {
	$("#updateP").on('submit',(function(e) {
		e.preventDefault();
		$.ajax({
        	url: "../controller/updateP.php",
			type: "POST",
			data:  new FormData(this),
			contentType: false,
    	    cache: false,
			processData:false,
				beforeSend: function() 
			{
				$(".info").html('<center><img class="gifi" src="../media/images/loader.gif" alt="Loading...." align="absmiddle" title="Loading...."/></center>');
			},
			success: function(data)
		    {
			$(".info").fadeIn(5000).html(data);
	
		    },
		  	error: function() 
	    	{
	    	} 	        
	   });
	}));
});
</script>


				<script type="text/javascript">
$(document).ready(function (e) {
	$("#signupadmin").on('submit',(function(e) {
		e.preventDefault();
		$.ajax({
        	url: "../controller/signup.php",
			type: "POST",
			data:  new FormData(this),
			contentType: false,
    	    cache: false,
			processData:false,
				beforeSend: function() 
			{
				$(".info").html('<center><img class="gifi" src="../media/images/loader.gif" alt="Loading...." align="absmiddle" title="Loading...."/></center>');
			},
			success: function(data)
		    {
			$(".info").fadeIn(5000).html(data);
	
		    },
		  	error: function() 
	    	{
	    	} 	        
	   });
	}));
});
</script>
				<script type="text/javascript">
$(document).ready(function (e) {
	$("#newDoc").on('submit',(function(e) {
		e.preventDefault();
		$.ajax({
        	url: "../controller/new_doc.php",
			type: "POST",
			data:  new FormData(this),
			contentType: false,
    	    cache: false,
			processData:false,
				beforeSend: function() 
			{
				$(".info").html('<center><img class="gifi" src="../media/images/loader.gif" alt="Loading...." align="absmiddle" title="Loading...."/></center>');
			},
			success: function(data)
		    {
			$(".info").fadeIn(5000).html(data);
	
		    },
		  	error: function() 
	    	{
	    	} 	        
	   });
	}));
});
</script>
				<script type="text/javascript">
$(document).ready(function (e) {
	$("#signup").on('submit',(function(e) {
		e.preventDefault();
		$.ajax({
        	url: "../controller/signup.php",
			type: "POST",
			data:  new FormData(this),
			contentType: false,
    	    cache: false,
			processData:false,
				beforeSend: function() 
			{
				$(".info").html('<center><img class="gifi" src="media/images/loader.gif" alt="Loading...." align="absmiddle" title="Loading...."/></center>');
			},
			success: function(data)
		    {
			$(".info").fadeIn(5000).html(data);
	
		    },
		  	error: function() 
	    	{
	    	} 	        
	   });
	}));
});
</script>







  </body>
</html>
