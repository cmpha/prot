      </div>
	  </div>
    </div>
<footer>

		<p>
			© 2017 <a href="">medical council of Malawi</a>
			
		</p>

	</footer>

    <!-- Placed at the end of the document so the pages load faster -->
	<!-- start: JavaScript-->

	<script src="../media/js/jquery.js"></script>
		<script src="../media/js/bootstrap.min.js"></script>
		<!--table--->
		 <script src="../media/js/jquery-1.7.2.min.js"></script>			
		 <script type="text/javascript" charset="utf-8" language="javascript" src="../media/js/jquery.dataTables.js"></script>
		<script type="text/javascript" charset="utf-8" language="javascript" src="../media/js/DT_bootstrap.js"></script>
	<!-- end: JavaScript-->
	
	
</script>
	<script type="text/javascript">
$(document).ready(function (e) {
	$("#newfolder").on('submit',(function(e) {
		e.preventDefault();
		$.ajax({
        	url: "../controller/newfolder.php",
			type: "POST",
			data:  new FormData(this),
			contentType: false,
    	    cache: false,
			processData:false,
				beforeSend: function() 
			{
				$(".info").html('<center><img class="gifi" src="../media/images/loader.gif" alt="Loading...." align="absmiddle" title="Loading...."/></center>');
			},
			success: function(data)
		    {
			$(".info").fadeIn(5000).html(data);
	
		    },
		  	error: function() 
	    	{
	    	} 	        
	   });
	}));
});
</script>


	<script type="text/javascript">
$(document).ready(function (e) {
	$("#Upuser").on('submit',(function(e) {
		e.preventDefault();
		$.ajax({
        	url: "../controller/update_user.php",
			type: "POST",
			data:  new FormData(this),
			contentType: false,
    	    cache: false,
			processData:false,
				beforeSend: function() 
			{
				$(".info").html('<center><img class="gifi" src="../media/images/loader.gif" alt="Loading...." align="absmiddle" title="Loading...."/></center>');
			},
			success: function(data)
		    {
			$(".info").fadeIn(5000).html(data);
	
		    },
		  	error: function() 
	    	{
	    	} 	        
	   });
	}));
});
</script>	






	
	<script type="text/javascript">
$(document).ready(function (e) {
	$("#newGroup").on('submit',(function(e) {
		e.preventDefault();
		$.ajax({
        	url: "../controller/new_group.php",
			type: "POST",
			data:  new FormData(this),
			contentType: false,
    	    cache: false,
			processData:false,
				beforeSend: function() 
			{
				$(".info").html('<center><img class="gifi" src="../media/images/loader.gif" alt="Loading...." align="absmiddle" title="Loading...."/></center>');
			},
			success: function(data)
		    {
			$(".info").fadeIn(5000).html(data);
	
		    },
		  	error: function() 
	    	{
	    	} 	        
	   });
	}));
});
</script>	
	
	<script type="text/javascript">
$(document).ready(function (e) {
	$("#newOrg").on('submit',(function(e) {
		e.preventDefault();
		$.ajax({
        	url: "../controller/new_org.php",
			type: "POST",
			data:  new FormData(this),
			contentType: false,
    	    cache: false,
			processData:false,
				beforeSend: function() 
			{
				$(".info").html('<center><img class="gifi" src="../media/images/loader.gif" alt="Loading...." align="absmiddle" title="Loading...."/></center>');
			},
			success: function(data)
		    {
			$(".info").fadeIn(5000).html(data);
	
		    },
		  	error: function() 
	    	{
	    	} 	        
	   });
	}));
});
</script>


	<script type="text/javascript">
$(document).ready(function (e) {
	$("#approve").on('submit',(function(e) {
		e.preventDefault();
		$.ajax({
        	url: "../controller/choose.php",
			type: "POST",
			data:  new FormData(this),
			contentType: false,
    	    cache: false,
			processData:false,
				beforeSend: function() 
			{
				$(".info").html('<center><img class="gifi" src="../media/images/loader.gif" alt="Loading...." align="absmiddle" title="Loading...."/></center>');
			},
			success: function(data)
		    {
			$(".info").fadeIn(5000).html(data);
	
		    },
		  	error: function() 
	    	{
	    	} 	        
	   });
	}));
});
</script>
	<script type="text/javascript">
$(document).ready(function (e) {
	$("#newshare").on('submit',(function(e) {
		e.preventDefault();
		$.ajax({
        	url: "../controller/share.php",
			type: "POST",
			data:  new FormData(this),
			contentType: false,
    	    cache: false,
			processData:false,
				beforeSend: function() 
			{
				$(".info").html('<center><img class="gifi" src="../media/images/loader.gif" alt="Loading...." align="absmiddle" title="Loading...."/></center>');
			},
			success: function(data)
		    {
			$(".info").fadeIn(5000).html(data);
	
		    },
		  	error: function() 
	    	{
	    	} 	        
	   });
	}));
});
</script>

	<script type="text/javascript">
$(document).ready(function (e) {
	$("#newevent").on('submit',(function(e) {
		e.preventDefault();
		$.ajax({
        	url: "../controller/new_event.php",
			type: "POST",
			data:  new FormData(this),
			contentType: false,
    	    cache: false,
			processData:false,
				beforeSend: function() 
			{
				$(".info").html('<center><img class="gifi" src="../media/images/loader.gif" alt="Loading...." align="absmiddle" title="Loading...."/></center>');
			},
			success: function(data)
		    {
			$(".info").fadeIn(5000).html(data);
	
		    },
		  	error: function() 
	    	{
	    	} 	        
	   });
	}));
});
</script>
			<script type="text/javascript">
$(document).ready(function (e) {
	$("#updateP").on('submit',(function(e) {
		e.preventDefault();
		$.ajax({
        	url: "../controller/updateP.php",
			type: "POST",
			data:  new FormData(this),
			contentType: false,
    	    cache: false,
			processData:false,
				beforeSend: function() 
			{
				$(".info").html('<center><img class="gifi" src="../media/images/loader.gif" alt="Loading...." align="absmiddle" title="Loading...."/></center>');
			},
			success: function(data)
		    {
			$(".info").fadeIn(5000).html(data);
	
		    },
		  	error: function() 
	    	{
	    	} 	        
	   });
	}));
});
</script>


				<script type="text/javascript">
$(document).ready(function (e) {
	$("#signupadmin").on('submit',(function(e) {
		e.preventDefault();
		$.ajax({
        	url: "../controller/signup.php",
			type: "POST",
			data:  new FormData(this),
			contentType: false,
    	    cache: false,
			processData:false,
				beforeSend: function() 
			{
				$(".info").html('<center><img class="gifi" src="../media/images/loader.gif" alt="Loading...." align="absmiddle" title="Loading...."/></center>');
			},
			success: function(data)
		    {
			$(".info").fadeIn(5000).html(data);
	
		    },
		  	error: function() 
	    	{
	    	} 	        
	   });
	}));
});
</script>
				<script type="text/javascript">
$(document).ready(function (e) {
	$("#newDoc").on('submit',(function(e) {
		e.preventDefault();
		$.ajax({
        	url: "../controller/new_doc.php",
			type: "POST",
			data:  new FormData(this),
			contentType: false,
    	    cache: false,
			processData:false,
				beforeSend: function() 
			{
				$(".info").html('<center><img class="gifi" src="../media/images/loader.gif" alt="Loading...." align="absmiddle" title="Loading...."/></center>');
			},
			success: function(data)
		    {
			$(".info").fadeIn(5000).html(data);
	
		    },
		  	error: function() 
	    	{
	    	} 	        
	   });
	}));
});
</script>
				<script type="text/javascript">
$(document).ready(function (e) {
	$("#signup").on('submit',(function(e) {
		e.preventDefault();
		$.ajax({
        	url: "../controller/signup.php",
			type: "POST",
			data:  new FormData(this),
			contentType: false,
    	    cache: false,
			processData:false,
				beforeSend: function() 
			{
				$(".info").html('<center><img class="gifi" src="media/images/loader.gif" alt="Loading...." align="absmiddle" title="Loading...."/></center>');
			},
			success: function(data)
		    {
			$(".info").fadeIn(5000).html(data);
	
		    },
		  	error: function() 
	    	{
	    	} 	        
	   });
	}));
});
</script>


			<script type="text/javascript">
    $(document).ready(function(){
        $counter = 0; // initialize 0 for limitting textboxes
        $('#buttonadd').click(function(){
            
                $counter++;
                $('#buttondiv').append('<div><label>user #'+$counter+' <div class="mpha"><div class="form-group"><label class="mylabel">Document name</label><input type="text" disabled="" class="form-control" value="<?php echo $document_name; ?>"><input type="hidden" name="document_id" class="form-control" value="<?php echo $document_id;?>"></div>	<div class="control-group"><label class="mylabel">Choose people</label><div class="controls"><select class="form-control" name="users[]"><option value="">Choose</option><?php $db_users=$dbtask->getUsers();while($row=$db_users->fetch(PDO::FETCH_ASSOC)){$user=$row['user_id'];$first_name=$row['first_name'];$last_name=$row['last_name'];$username=$row['username'];$password=$row['password'];$role=$row['role'];$date=$row['date'];$email=$row['email'];$status=$row['status'];?><option value="<?php echo $user;?>"><?php echo $username?></option><?php  } ?></select></div></div><div class="form-group"><label class="mylabel">Notes </label><textarea name="notes" class="form-control"></textarea></div><div class="control-group"><label class="mylabel">Status</label>  <div class="controls"><select class="form-control" name="status"><option value="">Choose</option><option value="High">high</option><option value="medium">medium</option><option value="low">low</option></select> </div></div><input type="hidden" name="owner" value="<?php echo $user_id;?>"><hr/></div></div>');
         
        });

        $('#buttonremove').click(function(){
            if ($counter){
                $counter--;
                $('#buttondiv .mpha:last').parent().remove(); 
            }else{
                alert('No More textbox to remove');
            }
        });
    });
</script>
	<!--<script> 
var auto_refresh = setInterval(
function()
{
$('.noti').load('../controller/noti.php').fadeIn("slow");
}, 3000);
</script>-->


  </body>
</html>
