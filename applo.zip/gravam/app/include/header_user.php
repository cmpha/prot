<?php
session_start();
if (!isset($_SESSION["user_id"])) {
    header("location:../index.php");
    exit();
}
$user_id=$_SESSION["user_id"];
$username=$_SESSION['username'];
$role=$_SESSION['role'] ;


include('../class/main_class.php');
$dbtask=new SYSTEM_CLASS();
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../media/images/ico.png">

    <title>Gravam</title>
    <link href="../media/css/bootstrap.min.css" rel="stylesheet">
    <link href="../media/css/style.css" rel="stylesheet">
	<link rel="stylesheet" href="../media/css/font-awesome.min.css" />

  </head>

  <body>

<!-- Header Starts -->
<div class="navbar-wrapper">

        <div class="navbar-inverse" role="navigation">
          <div class="container">
            <div class="navbar-header">
                     <img class="logo" src="../media/images/logo.png">

              <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target=".navbar-collapse">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
              </button>

            </div>


            <!-- Nav Starts -->
            <div class="navbar-collapse  collapse">
              <ul class="nav navbar-nav navbar-right">
			  
<div class="noti"> </div>
 				       
				  <li class="dropdown">
								<a class="dropdown-toggle" data-toggle="dropdown" href="#">
									<i class="halflings-icon white user"></i><?php echo $username;?>
									<span class="caret"></span>
								</a>
								<ul class="dropdown-menu">
									<li class="dropdown-menu-title">
										<span>Account Settings</span>
									</li>
									<li><a href="profile.php?id=<?php echo $user_id;?>"><i class="halflings-icon user"></i> Profile</a></li>
									<li><a href="logout.php"><i class="halflings-icon off"></i> Logout</a></li>
								</ul>
				  </li>
              </ul>
            </div>
            <!-- #Nav Ends -->

          </div>
        </div>

    </div>
	<!-- #Header ends-->
	
    <div class="container-fluid">
      <div class="row">
 <div class="col-sm-2 col-md-2 sidebar">
 
          <ul class="nav nav-sidebar">
 
                <li <?php if (basename($_SERVER['PHP_SELF']) == 'index.php') echo 'class="active"' ?>><a  href="index.php" >Dashboard <i class="fa fa-dashboard"></i></a></li>
           
                 <li <?php if (basename($_SERVER['PHP_SELF']) == 'folders.php') echo 'class="active"' ?>><a href="folders.php" >Folders <i class="fa fa-folder"></i></a></li>
				<li <?php if (basename($_SERVER['PHP_SELF']) == 'documents.php') echo 'class="active"' ?>><a href="documents.php" >Public documents <i class="fa fa-folder-open"></i></a>  </li>
				<li <?php if (basename($_SERVER['PHP_SELF']) == 'private.php') echo 'class="active"' ?>><a href="private.php" >Private documents <i class="fa fa-folder"></i></a></li>
				<li <?php if (basename($_SERVER['PHP_SELF']) == 'shared.php') echo 'class="active"' ?>><a href="shared.php" >Shared documents <i class="fa fa-folder-open"></i></a></li>

				 
          </ul>
		  
 </div>